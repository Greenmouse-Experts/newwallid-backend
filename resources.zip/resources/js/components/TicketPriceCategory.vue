<template>
  <div>
    <div class="card mb-4 bg-light px-2">
      <p class="px-3">
        <md-button class="md-icon-button md-raised md-accent float-right" @click="closeSection">
          <md-icon>delete</md-icon>
        </md-button>
      </p>

      <div class="row">
        <div class="col-6">
          <md-field>
               <md-icon>article</md-icon>
            <label>Category Name</label>
            <md-input type="text" v-on:blur="updateCategory"></md-input>
            <span class="md-helper-text">Category Name</span>
          </md-field>
        </div>

        <div class="col-6">
           <md-field>
                <md-icon>attach_money</md-icon>
            <label>Price</label>
            <md-input type="number" v-on:blur="updatePrice"></md-input>
            <span class="md-helper-text">Price</span>
          </md-field>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TicketPriceCategory",
  props: {
    index: Number,
  },

  methods: {
    updateCategory(event) {
      const element = event.target;
      const name = $(element).val();
      this.$emit("updateCategory", name, this.index);
    },

    updatePrice(event) {
      const element = event.target;
      const name = $(element).val();
      this.$emit("updatePrice", name, this.index);
    },

    closeSection() {
      this.$emit("closeSection", this.index);
    },
  },
};
</script>
