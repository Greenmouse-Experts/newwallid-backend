import Layout from './layouts/Dashboard.vue';


// Orgs
const OrgProfile = () => import('./pages/organization/Profile.vue');
const UpdateOrgrofile = () => import('./pages/organization/UpdateProfile.vue');
import OrganizationIndex from './pages/organization/Index.vue';
import Members from './pages/organization/membership/Members.vue';
import SubscriptionPlans from './pages/organization/membership/SubscriptionPlans.vue';
import Subscriptions from './pages/organization/membership/Subscriptions.vue'
import MembershipRequests from './pages/organization/membership/Requests.vue';
import MembershipRequestsInfo from './pages/organization/membership/RequestsInfo.vue';

const MemberProfile = () => import('./pages/organization/membership/Profile.vue');


// Admin
import Dashboard from './pages/admin/Dashboard.vue';
import Users from './pages/admin/users/Users.vue';
import Organizations from './pages/admin/organizations/Organizations.vue';
import AdminEvents from './pages/admin/events/Events.vue';
import AdminEventsCategory from './pages/admin/events/EventsCategory.vue';
import AdminTicketPayments from './pages/admin/payments/TicketPayments.vue';
import AdminSubscriptionPayments from './pages/admin/payments/SubscriptionPayments.vue';
import AdminsManagement from './pages/admin/admin/AdminsManagement.vue';


// Individual
const UserProfile = () => import('./pages/individual/Profile.vue');
const UpdateProfile = () => import('./pages/individual/UpdateProfile.vue');
const IndividualDashboard = () => import('./pages/individual/Dashboard.vue');
const UserOrganizations = () => import('./pages/individual/organizations/Index.vue');
const UserOrganizationSubscriptions = () => import('./pages/individual/organizations/Subscriptions.vue');
const OrganizationJoinRequest = () => import('./pages/individual/organizations/JoinRequests.vue');


// Gen
const ListEvents = () => import('./pages/events/List.vue');
const EventInfo = () => import('./pages/events/EventInfo.vue');
const CreateEvent = () => import('./pages/events/CreateOrUpdate.vue');
const EventRequests = () => import('./pages/events/Requests.vue');
const EventDetails = () => import('./pages/events/EventDetails.vue');
const EventInvitation = () => import('./pages/events/EventInvitation.vue');

const IDcardCreate = () => import('./pages/idcard/IDCardSPA.vue')
const IDcardView = () => import('./pages/idcard/IDcardView.vue')
const IDcardViewInfo = () => import('./pages/idcard/IDCardViewinfo.vue')


// Pages
const PaymentIndex = () => import('./pages/payments/Index.vue');
const TicketPayment = () => import('./pages/payments/Ticket.vue');

import PageNotFound from './views/PageNotFound.vue';


const routes = [

    // Pages
    {
        path: '/payments',
        component: Layout,

        children: [
            {
                path: 'ticket',
                name: 'ticket-payment',
                component: TicketPayment
            },

            {
                path: 'response',
                name: 'payment-response-page',
                component: PaymentIndex
            }
        ]
    },

    // Orgaization
    {
        path: '/organization',
        component: Layout,
        meta: {transition: 'zoom'},

        children: [
            {
                path: '/',
                name: OrganizationIndex,
                component: OrganizationIndex,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/create',
                name: 'create-event',
                component: CreateEvent,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/requests',
                name: 'update-event',
                component: EventRequests,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/invites',
                name: 'event-invites',
                component: EventInvitation,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/:id',
                name: 'event-details',
                component: EventDetails,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/:id/edit',
                name: 'update-event',
                component: CreateEvent,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/:id/info',
                name: 'event-info',
                component: EventInfo,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events',
                name: ListEvents,
                component: ListEvents,
                meta: {transition: 'zoom'},
            },

            {
                path: 'members',
                name: Members,
                component: Members,
                meta: {transition: 'zoom'},
            },

            {
                path: 'members/requests',
                name: 'membership-requests',
                component: MembershipRequests,
                meta: {transition: 'zoom'},
            },

            {
                path: 'members/requests/:id',
                name: 'membership-requests-info',
                component: MembershipRequestsInfo,
                meta: {transition: 'zoom'},
            },

            {
                path: 'members/:id',
                name: 'member-profile',
                component: MemberProfile,
                meta: {transition: 'zoom'},
            },


            {
                path: 'subscriptions/plans/:id',
                name: 'subscription-plans-view',
                component: SubscriptionPlans,
                meta: {transition: 'zoom'},
            },

            {
                path: 'subscriptions',
                name: Subscriptions,
                component: Subscriptions,
                meta: {transition: 'zoom'},
            },

            {
                path: 'subscriptions/plans',
                name: SubscriptionPlans,
                component: SubscriptionPlans,
                meta: {transition: 'zoom'},
            },

            {
                path: 'id_card',
                name: 'create-id-card',
                component: IDcardCreate,
                meta: {transition: 'zoom'},
            },

            {
                path: 'id_card/view/:id',
                name: 'view-id-card-info',
                component: IDcardViewInfo,
                meta: {transition: 'zoom'},
            },

            {
                path: 'id_card/view',
                name: 'view-id-card',
                component: IDcardView,
                meta: {transition: 'zoom'},
            },

            {
                path: 'profile',
                name: 'org-profile',
                component: OrgProfile,
                meta: {transition: 'zoom'},
            },

            {
                path: 'profile/edit',
                name: 'update-organization-profile',
                component: UpdateOrgrofile,
                meta: {transition: 'zoom'},
            }


        ]
    },


    /* Individual */
    {
        path: '/individual',
        component: Layout,
        meta: {transition: 'zoom'},

        children: [
            {
                path: '/',
                name: 'individual-dashboard',
                component: IndividualDashboard,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/create',
                name: 'create-event',
                component: CreateEvent,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/requests',
                name: 'update-event',
                component: EventRequests,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/invites',
                name: 'event-invites',
                component: EventInvitation,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/:id',
                name: 'event-details',
                component: EventDetails,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/:id/edit',
                name: 'update-event',
                component: CreateEvent,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/:id/info',
                name: 'event-info',
                component: EventInfo,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events',
                name: ListEvents,
                component: ListEvents,
                meta: {transition: 'zoom'},
            },

            {
                path: 'organizations/join-request',
                name: 'organizations-join-request',
                component: OrganizationJoinRequest,
                meta: {transition: 'zoom'},
            },

            {
                path: 'organizations',
                name: 'my-organizations',
                component: UserOrganizations,
                meta: {transition: 'zoom'},
            },
            {
                path: 'organizations/:id/subscriptions',
                name: 'my-organization-subscriptions',
                component: UserOrganizationSubscriptions,
                meta: {transition: 'zoom'},
            },

            {
                path: 'profile',
                name: 'user-profile',
                component: UserProfile,
                meta: {transition: 'zoom'},
            },
            {
                path: 'id_card',
                name: 'create-id-card',
                component: IDcardCreate,
                meta: {transition: 'zoom'},
            },

            {
                path: 'id_card/view/:id',
                name: 'view-id-card-info',
                component: IDcardViewInfo,
                meta: {transition: 'zoom'},
            },

            {
                path: 'id_card/view',
                name: 'view-id-card',
                component: IDcardView,
                meta: {transition: 'zoom'},
            },
            {
                path: 'profile/edit',
                name: 'update-profile',
                component: UpdateProfile,
                meta: {transition: 'zoom'},
            }
        ]
    },


    /* Admin */
    {
        path: '/admin',
        component: Layout,
        meta: {transition: 'zoom'},

        children: [
            {
                path: '/',
                name: 'admin-dashboard',
                component: Dashboard,
                meta: {transition: 'zoom'},
            },
            {
                path: 'users',
                name: 'admin-all-users',
                component: Users,
                meta: {transition: 'zoom'},
            },
            {
                path: 'users/:status',
                name: 'admin-specific-users',
                component: Users,
                meta: {transition: 'zoom'},
            },
            {
                path: 'organizations',
                name: 'admin-all-organizations',
                component: Organizations,
                meta: {transition: 'zoom'},
            },
            {
                path: 'organizations/:status',
                name: 'admin-specific-organizations',
                component: Organizations,
                meta: {transition: 'zoom'},
            },
            {
                path: 'events',
                name: 'admin-events',
                component: AdminEvents,
                meta: {transition: 'zoom'},
            },

            {
                path: 'events/category',
                name: 'admin-events-category',
                component: AdminEventsCategory,
                meta: {transition: 'zoom'},
            },
            {
                path: 'events/:id',
                name: 'admin-event-details',
                component: EventDetails,
                meta: {transition: 'zoom'},
            },
            {
                path: 'payments/tickets',
                name: 'admin-tickets-payments',
                component: AdminTicketPayments,
                meta: {transition: 'zoom'},
            },
            {
                path: 'payments/subscriptions',
                name: 'admin-subscriptions-payments',
                component: AdminSubscriptionPayments,
                meta: {transition: 'zoom'},
            },
            {
                path: 'all_admins',
                name: 'admin-all',
                component: AdminsManagement,
                meta: {transition: 'zoom'},
            },

        ]
    },


    {
        path: '**',
        name: 'page-not-found',
        component: PageNotFound,
        meta: {transition: 'zoom'},
    }
]

export default routes;
