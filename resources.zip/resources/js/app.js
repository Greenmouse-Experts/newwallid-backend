require('./bootstrap');
window.Vue = require('vue').default;

// Form
import { Form, HasError, AlertError } from 'vform';
window.Form = Form;
// Vue.component(HasError.name, HasError);
// Vue.component(AlertError.name, AlertError);

// Router
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// Routes
import routes from './routes';
const router = new VueRouter({ mode: 'history', routes: routes });

// Components
import DashSidebar from './components/DashSidebar.vue';
import DashHeader from './components/DashHeader.vue';

// Store
import store from './store';

// Loader
import LoaderSpinner from 'vue-loader-spinner'
Vue.use(LoaderSpinner)

// Trans
import VuePageTransition from 'vue-page-transition'
Vue.use(VuePageTransition)

// Dialog
import VModal from 'vue-js-modal'
import VueConfirmDialog from 'vue-confirm-dialog'
Vue.use(VModal)
Vue.use(VueConfirmDialog)

// Noti
import Notifications from 'vue-notification'
Vue.use(Notifications)

// Toggle
import ToggleButton from 'vue-js-toggle-button'
Vue.use(ToggleButton)

import VueQr from 'vue-qr'
Vue.use(VueQr)

//Moment
Vue.use(require('vue-moment'));

//Time Picker
import VueTimepicker from 'vue2-timepicker'
Vue.use(VueTimepicker)
// CSS
import 'vue2-timepicker/dist/VueTimepicker.css'

//select niput
import VueMaterial from 'vue-material'
import 'vue-material/dist/vue-material.min.css'
import 'vue-material/dist/theme/default.css'

Vue.use(VueMaterial)

// Standalone
import Pagination from 'laravel-vue-pagination';
import Breadcrumb from './components/Breadcrumb.vue';
import UnreadNotification from './components/notification/Unread.vue';

import AOS from 'aos';
import 'aos/dist/aos.css'; // You can also use <link> for styles
// ..
AOS.init();

//format currency
var numeral = require('numeral');

Vue.filter("formatCurrency", function (value) {
    return numeral(value).format("0,0.00"); // displaying other groupings/separators is possible, look at the docs
  });

Vue.component('pagination', Pagination);
Vue.component('breadcrumb', Breadcrumb);
Vue.component('UnreadNotification', UnreadNotification);
Vue.component('pagination', require('laravel-vue-pagination'));


//
Vue.prototype.$auth = window.user;


const app = new Vue({
    el: '#app',
    router,
    store,

});
