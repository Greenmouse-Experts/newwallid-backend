<template>
  <div>
    <md-card md-with-hover class="round-card">
      <md-ripple>
        <md-card-header>
          <div class="md-title">View ID Card</div>
          <!-- <div class="md-subhead">It also have a ripple</div> -->
        </md-card-header>

        <md-card-content>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio itaque
          ea, nostrum odio. Dolores, sed accusantium quasi non.
        </md-card-content>

        <md-card-actions>
          <md-button>Action</md-button>
          <md-button>Action</md-button>
        </md-card-actions>
      </md-ripple>
    </md-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      idCard: null,
    };
  },

  methods: {
    getIDCard(id) {
      this.$spinner.show();
      axios
        .get("/api/ids/show/" + id)
        .then((response) => {
          this.idCard = response.data.data;
        //   this.event_request = response.data.rdata;
        //   this.purchased_tickets = response.data.pdata;
          this.$notify({
            title: "success",
            text: response.data.message,
          });
        })
        .catch((e) => {
          this.$notify({
            title: "Error",
            text: e.response.data.message,
          });
        })
        .finally((e) => {
          this.$spinner.hide();
        });
    },

    getImage(image) {
      return "/events/" + image;
    },
  },

  mounted() {
    this.getIDCard(this.$route.params.id);
  },
};
</script>

