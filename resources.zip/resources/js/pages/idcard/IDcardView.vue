<template>
    <div>
        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <h1 class="md-title">{{ filter }} ID Cards</h1>
                    <div class="float-right">
                        <div
                            class="btn-group"
                            role="group"
                            aria-label="Basic example"
                        >
                            <md-menu md-size="auto">
                                <md-button md-menu-trigger class="md-fab md-mini bg-edit md-raised">
                                    <md-icon>filter_list</md-icon>
                                </md-button>

                                <md-menu-content>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getAllCards">
                                            All ID Cards
                                        </md-button>
                                    </md-menu-item>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getBusinessCards">
                                            Business ID Cards
                                        </md-button>
                                    </md-menu-item>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getHealthCards">
                                            Health ID Cards
                                        </md-button>
                                    </md-menu-item>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getStudentCards">
                                            Student ID Cards
                                        </md-button>
                                    </md-menu-item>
                                </md-menu-content>
                            </md-menu>
                        </div>
                    </div>
                </md-card-header>

                <md-card-content>
                    <div class="mt-4">
                        <md-table class="round-card">
                            <md-table-row>
                                <md-table-head class="text-center">ID</md-table-head>
                                <md-table-head class="text-center">Name</md-table-head>
                                <md-table-head class="text-center">Issued By</md-table-head>
                                <md-table-head class="text-center">Issued Date</md-table-head>
                                <md-table-head class="text-center">Expiry Date</md-table-head>
                                <md-table-head class="text-center">Category</md-table-head>
                                <md-table-head class="text-center">Role</md-table-head>
                                <md-table-head class="text-center">Actions</md-table-head>
                            </md-table-row>

                            <md-table-row
                                class="text-center"
                                v-for="id in id_cards"
                                :key="id.id"
                            >
                                <md-table-cell class="text-center" md-numeric>
                                    {{ id.id }}
                                </md-table-cell>
                                <md-table-cell class="text-center"
                                >{{ id.firstname }} {{ id.lastname }}
                                </md-table-cell
                                >
                                <md-table-cell
                                    class="text-center text-capitalize"
                                    v-if="id.created_by_individual != null"
                                >
                                    {{ id.created_by_individual.firstname + ' ' + id.created_by_individual.lastname }}
                                </md-table-cell>
                                <md-table-cell
                                    class="text-center text-capitalize"
                                    v-if="id.created_by_organization != null"
                                >
                                    {{ id.created_by_organization.name }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{
                                        id.issued_date
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{
                                        id.expiry_date
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center text-capitalize">{{
                                        id.category
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center text-capitalize">{{
                                        id.role
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <div
                                        class="btn-group"
                                        role="group"
                                        aria-label="Basic example"
                                    >
                                        <md-button
                                            class="md-fab md-mini"
                                            :to="$route.path + '/' + id.id"
                                        >
                                            <md-icon>visibility</md-icon>
                                            <md-tooltip md-direction="bottom"
                                            >View ID Card
                                            </md-tooltip
                                            >
                                        </md-button>
                                    </div>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>

                <md-card-actions>
                    <div class="float-right">
                        <pagination
                            :data="pagination"
                            @pagination-change-page="loadMyIDCards"
                            page="1"
                        ></pagination>
                    </div>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>
<style lang="scss" scoped>
.md-menu-content {
    z-index: 110;
}
</style>

<script>
export default {
    data() {
        return {
            id_cards: [],
            api_path: "/api/ids/user",
            filter: "All My",
            pagination: {},
        };
    },

    methods: {
        loadMyIDCards(page = 1) {
            this.$spinner.show();
            axios
                .get(this.api_path + "?page=" + page)
                .then((response) => {
                    this.prepPagination(response.data);
                    this.id_cards = response.data.data;
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        getAllCards(){
            this.api_path = "/api/ids/user";
            this.loadMyIDCards();
            this.filter = "All My";
        },

        getBusinessCards(){
            this.api_path = "/api/ids/user/business";
            this.loadMyIDCards();
            this.filter = "All My Business";
        },

        getHealthCards(){
            this.api_path = "/api/ids/user/health";
            this.loadMyIDCards();
            this.filter = "All My Health";
        },

        getStudentCards(){
            this.api_path = "/api/ids/user/students";
            this.loadMyIDCards();
            this.filter = "All My Student";
        },
    },

    mounted() {
        this.loadMyIDCards();
    },
};
</script>
