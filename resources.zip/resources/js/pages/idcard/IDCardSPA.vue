<template>
    <div>
        <!-- modal for add or edit ID Card -->
        <modal
            name="id-card-management"
            :adaptive="true"
            :scrollable="true"
            height="auto"
        >
            <div class="mt-3 text-center">
                <h4>
                    {{ edit_mode ? "Edit ID Card" : "Create ID Card" }}
                </h4>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <md-field :class="getValidationClass('name')">
                            <md-icon>article</md-icon>
                            <label>Holder Username</label>
                            <md-input v-model="form.name" :disabled="edit_mode"></md-input>
                            <div
                                v-if="form.errors.has('name')"
                                class="md-error"
                                v-html="form.errors.get('name')"
                            />
                            <span class="md-helper-text">Wall-ID Username</span>
                        </md-field>
                    </div>

                    <div class="col-md-6">
                        <md-field :class="getValidationClass('role')">
                            <md-icon>article</md-icon>
                            <label>Role</label>
                            <md-input v-model="form.role"></md-input>
                            <div
                                v-if="form.errors.has('role')"
                                class="md-error"
                                v-html="form.errors.get('role')"
                            />
                            <span class="md-helper-text">Role of the User</span>
                        </md-field>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <md-field :class="getValidationClass('image')">
                            <label>Passport</label>
                            <md-file @change="handleimage" accept="image/*"/>
                            <div
                                v-if="form.errors.has('image')"
                                class="md-error"
                                v-html="form.errors.get('image')"
                            />
                            <span class="md-helper-text" v-if="!edit_mode"
                            >ID card Holder Picture</span
                            >
                            <span class="md-helper-text" v-if="edit_mode"
                            >Leave blank if you want to retain the old image</span
                            >
                        </md-field>
                    </div>

                    <div class="col-md-6">
                        <md-field :class="getValidationClass('category')">
                            <md-icon>list</md-icon>
                            <label for="movies">ID Card Category</label>
                            <md-select
                                v-model="form.category"
                                name="category_id"
                                id="category_id"
                            >
                                <md-option value="business"> Business</md-option>
                                <md-option value="health"> Health</md-option>
                                <md-option value="student"> Student</md-option>
                            </md-select>
                            <div
                                v-if="form.errors.has('category')"
                                class="md-error"
                                v-html="form.errors.get('category')"
                            />
                            <span class="md-helper-text">ID card Category</span>
                        </md-field>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <md-field :class="getValidationClass('issued_date')">
                            <md-icon>event</md-icon>
                            <label>Date Issued</label>
                            <md-input v-model="form.issued_date" type="date"></md-input>
                            <div
                                v-if="form.errors.has('issued_date')"
                                class="md-error"
                                v-html="form.errors.get('issued_date')"
                            />
                            <span class="md-helper-text">ID card Issued Date</span>
                        </md-field>
                    </div>

                    <div class="col-md-6">
                        <md-field :class="getValidationClass('expiry_date')">
                            <md-icon>event</md-icon>
                            <label>Expiry Date</label>
                            <md-input v-model="form.expiry_date" type="date"></md-input>
                            <div
                                v-if="form.errors.has('expiry_date')"
                                class="md-error"
                                v-html="form.errors.get('expiry_date')"
                            />
                            <span class="md-helper-text">ID card Expiry Date</span>
                        </md-field>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <md-field :class="getValidationClass('template_name')">
                            <md-icon>list</md-icon>
                            <label for="movies">ID Card Layout</label>
                            <md-select
                                v-model="form.layout"
                                name="category_id"
                                id="category_id"
                            >
                                <md-option value="horizontal"> Horizontal</md-option>
                                <md-option value="portrait"> Portrait</md-option>
                            </md-select>
                            <div
                                v-if="form.errors.has('layout')"
                                class="md-error"
                                v-html="form.errors.get('layout')"
                            />
                            <span class="md-helper-text">ID card Layout</span>
                        </md-field>
                    </div>

                    <div class="col-md-6">
                        <md-button
                            class="md-dense md-raised md-primary mt-4"
                            @click="$modal.show('template_designs')"
                        >Choose ID Card Template Design
                        </md-button
                        >
                        <div
                            style="color: red"
                            v-if="form.errors.has('template_name')"
                            class="md-error"
                            v-html="form.errors.get('template_name')"
                        />
                        <!-- <md-field :class="getValidationClass('role')">
                          <md-icon>article</md-icon>
                          <label>Role</label>
                          <md-input v-model="form.role"></md-input>
                          <div
                            v-if="form.errors.has('role')"
                            class="md-error"
                            v-html="form.errors.get('role')"
                          />
                          <span class="md-helper-text">Role of the User</span>
                        </md-field> -->
                    </div>
                </div>

                <div class="mt-2 mb-5">
                    <div class="float-right">
                        <md-button
                            :disabled="form.busy"
                            v-if="edit_mode"
                            @click="UpdateIDCard"
                            class="md-dense md-raised md-primary"
                        >
                            {{ submitting ? "updating" : "update" }}
                        </md-button>

                        <md-button
                            :disabled="form.busy"
                            v-if="!edit_mode"
                            @click="saveIDCard"
                            class="md-dense md-raised md-primary"
                        >
                            {{ submitting ? "creating" : "create" }}
                        </md-button>
                    </div>
                </div>
            </div>
        </modal>
        <!--end modal for add or edit ID Card -->

        <!-- modal for template Design -->
        <modal name="template_designs" height="auto" width="60%">
            <div class="container mt-2 mb-5">
                <md-card-header>
                    <div class="md-title text-center">
                        Available ID Card Design Templates
                    </div>
                </md-card-header>
                <div class="row">
                    <div class="col-md-6">
                        <md-radio
                            class="text-center"
                            v-model="form.template_name"
                            value="template_1"
                        >Template 1
                        </md-radio
                        >
                        <div class="template_card">
                            <div class="card__front card__part"></div>

                            <div class="card__back card__part">back</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <md-radio
                            class="text-center"
                            v-model="form.template_name"
                            value="template_2"
                        >Template 2
                        </md-radio
                        >
                        <div class="template_card">
                            <div class="card__front card__part">front</div>

                            <div class="card__back card__part">back</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <md-radio
                            class="text-center"
                            v-model="form.template_name"
                            value="template_3"
                        >Template 3
                        </md-radio
                        >
                        <div class="template_card">
                            <div class="card__front card__part">front</div>

                            <div class="card__back card__part">back</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <md-radio
                            class="text-center"
                            v-model="form.template_name"
                            value="template_4"
                        >Template 4
                        </md-radio
                        >
                        <div class="template_card">
                            <div class="card__front card__part">front</div>

                            <div class="card__back card__part">back</div>
                        </div>
                    </div>
                </div>
            </div>
        </modal>
        <!-- end modal for design template design -->

        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <h1 class="md-title">{{ filter }} ID Cards Created</h1>

                    <div class="float-right">
                        <div
                            class="btn-group"
                            role="group"
                            aria-label="Basic example"
                        >
                            <md-button
                                class="md-dense md-raised md-primary mr-3"
                                @click="showDialog()"
                            >Create
                            </md-button>

                            <md-menu md-size="auto">
                                <md-button md-menu-trigger class="md-fab md-mini bg-edit md-raised">
                                    <md-icon>filter_list</md-icon>
                                </md-button>

                                <md-menu-content>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getAllCards">
                                            All ID Cards
                                        </md-button>
                                    </md-menu-item>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getBusinessCards">
                                            All Business ID Cards
                                        </md-button>
                                    </md-menu-item>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getHealthCards">
                                            All Health ID Cards
                                        </md-button>
                                    </md-menu-item>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getStudentCards">
                                            All Student ID Cards
                                        </md-button>
                                    </md-menu-item>
                                </md-menu-content>
                            </md-menu>

                        </div>
                    </div>

                </md-card-header>

                <md-card-content>
                    <div class="mt-4">
                        <md-table class="round-card">
                            <md-table-row>
                                <md-table-head class="text-center">ID</md-table-head>
                                <md-table-head class="text-center">Name</md-table-head>
                                <md-table-head class="text-center">Issued Date</md-table-head>
                                <md-table-head class="text-center">Expiry Date</md-table-head>
                                <md-table-head class="text-center">Category</md-table-head>
                                <md-table-head class="text-center">Role</md-table-head>
                                <md-table-head class="text-center">Actions</md-table-head>
                            </md-table-row>

                            <md-table-row
                                class="text-center"
                                v-for="id in id_cards"
                                :key="id.id"
                            >
                                <md-table-cell class="text-center" md-numeric>
                                    {{ id.id }}
                                </md-table-cell>
                                <md-table-cell class="text-center text-capitalize"
                                >{{ id.firstname }} {{ id.lastname }}
                                </md-table-cell
                                >
                                <md-table-cell class="text-center">{{
                                        id.issued_date
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{
                                        id.expiry_date
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center text-capitalize">{{
                                        id.category
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center text-capitalize">{{
                                        id.role
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <div
                                        class="btn-group"
                                        role="group"
                                        aria-label="Basic example"
                                    >
                                        <md-button
                                            class="md-fab md-mini bg-edit"
                                            @click="editIDCardCategory(id)"
                                        >
                                            <md-icon>edit</md-icon>
                                            <md-tooltip md-direction="bottom"
                                            >Edit ID Card
                                            </md-tooltip
                                            >
                                        </md-button>

                                        <md-button
                                            class="md-fab md-mini"
                                            @click="confirmDelete(id.id)"
                                        >
                                            <md-icon>delete</md-icon>
                                            <md-tooltip md-direction="bottom"
                                            >Delete ID Card
                                            </md-tooltip
                                            >
                                        </md-button>

                                        <md-button
                                            class="md-fab md-mini"
                                            :to="$route.path + '/view/' + id.id"
                                        >
                                            <md-icon>visibility</md-icon>
                                            <md-tooltip md-direction="bottom"
                                            >View ID Card
                                            </md-tooltip
                                            >
                                        </md-button>
                                    </div>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>

                <md-card-actions>
                    <div class="float-right">
                        <pagination
                            :data="pagination"
                            @pagination-change-page="loadCreatedIDCards"
                            page="1"
                        ></pagination>
                    </div>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>
<style lang="scss" scoped>
.md-menu-content {
    z-index: 110;
}
</style>

<script>
export default {
    data() {
        return {
            id_cards: [],
            edit_mode: false,
            api_path: "/api/ids/created_ids",
            filter: "All",
            pagination: {},
            submitting: false,
            form: new Form({
                id: "",
                name: "",
                template_name: "",
                issued_date: "",
                expiry_date: "",
                category: "",
                image: "",
                role: "",
                layout: "",
            }),
        };
    },

    methods: {
        getValidationClass(fieldName) {
            const field = this.form.errors.has(fieldName);
            if (field) {
                return "md-invalid";
            }
        },

        showDialog() {
            this.$modal.show("id-card-management");
            this.form.reset();
            this.form.errors.clear();
            this.edit_mode = false;
        },

        handleimage(event) {
            let file = event.target.files[0];
            //console.log(form)
            let reader = new FileReader();
            reader.onload = (event) => {
                this.form.image = event.target.result;
                console.log(event.target.result);
            };
            reader.readAsDataURL(file);
        },

        saveIDCard() {
            this.$spinner.show();
            this.submitting = true;
            this.form
                .post("/api/ids/store")
                .then((response) => {
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                    this.form.reset();
                    this.$modal.hide("id-card-management");
                    this.loadCreatedIDCards();
                })
                .catch((e) => {
                    if (e.response.status == 422) {
                        this.form.errors.set(e.response.data.error);
                        console.log("422", e.response);
                    }

                    console.log("Error", e.response.status);
                    this.$notify({
                        type: "warn",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                    this.submitting = false;
                });
        },

        loadCreatedIDCards(page = 1) {
            this.$spinner.show();
            axios
                .get(this.api_path + "?page=" + page)
                .then((response) => {
                    this.prepPagination(response.data);
                    this.id_cards = response.data.data;
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        editIDCardCategory(data) {
            this.edit_mode = true;
            this.form.reset();
            this.form.errors.clear();
            this.form.fill(data);
            this.$modal.show("id-card-management");
        },

        UpdateIDCard() {
            this.$spinner.show();
            this.submitting = true;
            this.form
                .put("/api/ids/update/" + this.form.id)
                .then((response) => {
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                    this.form.reset();
                    this.$modal.hide("id-card-management");
                    this.loadCreatedIDCards();
                })
                .catch((e) => {
                    console.log("Error", e);
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                    this.submitting = false;
                });
        },

        confirmDelete(id) {
            this.$confirm({
                message: "Are you sure you want to delete this ID Card?",
                button: {
                    no: "No",
                    yes: "Yes",
                },
                callback: (confirm) => {
                    if (confirm) {
                        this.doDelete(id);
                    }
                },
            });
        },

        doDelete(id) {
            this.$spinner.show();
            axios
                .delete("/api/ids/delete/" + id)
                .then((response) => {
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });

                    this.loadCreatedIDCards();
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        getAllCards(){
            this.api_path = "/api/ids/created_ids";
            this.loadCreatedIDCards();
            this.filter = "All";
        },

        getBusinessCards(){
            this.api_path = "/api/ids/created_ids/business";
            this.loadCreatedIDCards();
            this.filter = "All Business";
        },

        getHealthCards(){
            this.api_path = "/api/ids/created_ids/health";
            this.loadCreatedIDCards();
            this.filter = "All Health";
        },

        getStudentCards(){
            this.api_path = "/api/ids/created_ids/students";
            this.loadCreatedIDCards();
            this.filter = "All Student";
        },
    },

    mounted() {
        this.loadCreatedIDCards();
    },
};
</script>
