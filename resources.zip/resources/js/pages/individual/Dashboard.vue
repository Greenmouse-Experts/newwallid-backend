<template>
    <div>
        <h4 class="h3 mb-4">{{ getTime() }}
            <span v-if="user && user.profile" class="font-weight-bold">
				{{ user.profile.details.firstname + ' ' + user.profile.details.lastname }}
			</span>
        </h4>

        <div class="row">
            <div class="col-md-9 mb-4">
                <div class="row mb-4">
                    <div class="col-md-6 mb-4">
                        <md-card md-with-hover class="round-card">
                            <md-ripple>
                                <md-card-content>
                                    <p>
                                        <i class="fas fa-users text-primary" style="font-size: 30px;"></i>
                                        <span style="float: right; font-weight: bold;">
										{{ dashdata.totalOrgs }}
									</span>
                                    </p>
                                    <p>
                                        <span>Organizations</span>
                                    </p>
                                </md-card-content>
                            </md-ripple>
                        </md-card>
                    </div>

                    <div class="col-md-6">
                        <md-card md-with-hover class="round-card">
                            <md-ripple>
                                <md-card-content>
                                    <p>
                                        <i class="fas fa-calendar text-primary" style="font-size: 30px;"></i>
                                        <span style="float: right; font-weight: bold;">
										{{ dashdata.totalEvents }}
									</span>
                                    </p>
                                    <p>
                                        <span>Events</span>
                                    </p>
                                </md-card-content>
                            </md-ripple>
                        </md-card>
                    </div>
                </div>


                <md-card md-with-hover class="round-card">
                    <md-ripple>
                        <md-card-header>
                            <div class="md-title">Membership join Requests Awaiting Approval</div>
                        </md-card-header>

                        <md-card-content>
                            <md-table>
                                <md-table-row>
                                    <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                    <md-table-head class="text-center">Organization Name</md-table-head>
                                    <md-table-head class="text-center">Organization Email</md-table-head>
                                    <md-table-head class="text-center">Sent on</md-table-head>
                                    <md-table-head class="text-center">Approval Status</md-table-head>
                                </md-table-row>

                                <md-table-row v-for="(row, index) in dashdata.organizations" :key="row.id">
                                    <md-table-cell class="text-center" md-numeric>{{ index + 1 }}</md-table-cell>
                                    <md-table-cell class="text-center">{{ row.organization.name }}</md-table-cell>
                                    <md-table-cell class="text-center">{{ row.organization.user.email }}</md-table-cell>
                                    <md-table-cell class="text-center">{{ row.created_at | moment("from", "now") }}</md-table-cell>
                                    <md-table-cell class="text-center">
                                        <md-chip class="md-primary">
                                            {{ row.status }}
                                        </md-chip>
                                    </md-table-cell>
                                </md-table-row>
                            </md-table>
                        </md-card-content>
                    </md-ripple>
                </md-card>
            </div>

            <div class="col-md-3">
                <md-card md-with-hover class="round-card mb-4">
                    <md-ripple>
                        <md-card-content>
                            <h4 class="card-title">Upcoming Event</h4>
                            <p>
                                <span class="small text-muted">Title</span> <br>
                                <span>Tech Talk</span>
                            </p>

                            <p>
                                <span class="small text-muted">Date</span> <br>
                                <span>20/10/2021</span>
                            </p>
                            <p>
                                <span class="small text-muted">Description</span> <br>
                                <span>
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua.
							</span>
                            </p>
                        </md-card-content>
                    </md-ripple>
                </md-card>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'IndividualDashboard',
    data() {
        return {
            user: null,
            dashdata: {
                totalOrgs: 0,
                totalEvents: 0,
                organizations: []
            }
        }
    },

    methods: {

        loadDashData() {

            this.$spinner.show();
            axios.get('/api/individuals')
                .then(response => {
                    this.dashdata = response.data.data
                })
                .catch(e => {
                    this.$notify({
                        type: 'error',
                        text: e.message
                    })
                })
                .finally(() => {
                    this.$spinner.hide();
                })
        },

        getTime() {
            const d = new Date();
            const time = d.getHours();

            if (time < 12) {
                return "Good Morning";
            } else if (time >= 12 && time <= 17) {
                return "Good Afternoon";
            } else if (time >= 17 && time <= 24) {
                return "Good Evening";
            }
        }
    },

    mounted() {
        this.user = this.$store.state.user;
        this.loadDashData();
    }
}
</script>
