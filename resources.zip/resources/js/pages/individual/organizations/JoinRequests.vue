<template>
    <div>
        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">Send Request to join an Organization</div>
                    <div class="md-subhead">
                        Send a request to an Organization to become one of its member !
                    </div>
                </md-card-header>

                <md-card-content>
                    <div>
                        <form
                            class="form-row"
                            @submit.prevent="checkOrg"
                            @keydown="form.onKeydown($event)"
                        >
                            <div class="col-md-8">
                                <md-field>
                                    <md-icon>article</md-icon>
                                    <label>Name</label>
                                    <md-input v-model="form.name"></md-input>
                                    <span class="md-helper-text">Wall-ID Username</span>
                                </md-field>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <button class="btn btn-primary">Check</button>
                            </div>
                        </form>
                    </div>
                </md-card-content>
            </md-ripple>
        </md-card>

        <md-card md-with-hover class="round-card mt-4">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">My Join Requests</div>
                </md-card-header>

                <md-card-content>
                    <div>
                        <md-table>
                            <md-table-row>
                                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                <md-table-head class="text-center">Name</md-table-head>
                                <md-table-head class="text-center">Phone</md-table-head>
                                <md-table-head class="text-center">Date Sent</md-table-head>
                                <md-table-head class="text-center">Status</md-table-head>
                            </md-table-row>

                            <md-table-row v-for="(row, index) in join_requests" :key="row.id">
                                <md-table-cell class="text-center" md-numeric>{{
                                        index + 1
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center"
                                >{{ row.organization.name }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{
                                        row.organization.phone
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{
                                        row.created_at | moment("from", "now")
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <md-chip :class="getStatus(row.status)">{{
                                            row.status
                                        }}
                                    </md-chip>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>

                <md-card-actions>
                    <pagination
                        :data="pagination"
                        @pagination-change-page="loadJoinRequests"
                        page="1"
                    ></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>

<script>
export default {
    name: "User Join Requests to Organizations",

    data() {
        return {
            form: new Form({
                name: "",
            }),

            join_requests: [],
            pagination: {},
            api_path: "/api/individuals/organizations/join-requests",
        };
    },

    methods: {
        loadJoinRequests(page = 1) {
            this.$spinner.show();
            axios
                .get(this.api_path + "?page=" + page)
                .then((response) => {
                    console.log(response);
                    this.prepPagination(response.data);
                    this.join_requests = response.data.data;
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        getStatus(data) {
            if (data == "pending") {
                return "md-primary";
            } else if (data == "declined") {
                return "md-accent";
            } else {
                return "bg-success";
            }
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        checkOrg() {
            this.$spinner.show();
            this.form
                .post("/api/individuals/organizations/join-request")
                .then((response) => {
                    this.$notify({
                        type: response.data.status ? "success" : "warn",
                        text: response.data.message,
                    });
                    this.loadJoinRequests();
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },
    },

    mounted() {
        this.loadJoinRequests();
    },
};
</script>
