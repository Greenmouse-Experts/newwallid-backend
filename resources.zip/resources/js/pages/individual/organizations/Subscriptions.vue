<template>
    <div>
        <!--        payment details modal-->
        <modal
            :adaptive="true"
            :scrollable="true"
            height="auto"
            @before-close="clearPaymentModal"
            name="payment_details">
            <div>
                <md-card md-with-hover class="round-card mr-4 ml-4 mt-4 mb-4">
                    <md-ripple>
                        <md-card-header>
                            <div class="md-title text-center">Payment Details</div>
                        </md-card-header>

                        <md-card-content>
                            <div>
                                <p><b>ID: </b> {{ payment_details.id }}</p>
                                <p><b>Payment Reference: </b> {{ payment_details.reference }} </p>
                                <p><b>Subscription ID: </b> {{ payment_details.subscription_id }}</p>
                                <p><b>Amount: </b> {{ payment_details.amount |formatCurrency }}</p>
                                <p><b>Payment Channel: </b> {{ payment_details.channel }}</p>
                                <p><b>Paid At: </b> {{ payment_details.paid_at | moment("dddd, Do MMMM YYYY") }}</p>

                            </div>
                        </md-card-content>

                        <md-card-actions>
                            <md-chip :class="getStatus(payment_details.status)">{{ payment_details.status }}</md-chip>
                        </md-card-actions>
                    </md-ripple>
                </md-card>
            </div>
        </modal>

        <modal
            :adaptive="true"
            :scrollable="true"
            height="auto"
            @before-close="clearPaymentModal"
            name="subscription">
            <div>
                <md-card md-with-hover class="round-card mr-3 ml-3 mt-4 mb-4">
                    <md-ripple>
                        <md-card-header>
                            <div class="md-title text-center">Add Subscription</div>
                        </md-card-header>

                        <md-card-content>
                            <div>
                                <div class="container">
                                    <md-field>
                                        <md-select v-model="subscription_plan_id" name="plans" id="plans"
                                                   placeholder="Subscription Plans">
                                            <md-option v-for="row in subscription_plans" :key="row.id" :value="row.id">
                                                {{ row.name }} -- {{row.price | formatCurrency}} ( {{row.validity}} days)
                                            </md-option>
                                        </md-select>
                                    </md-field>
                                </div>
                            </div>
                        </md-card-content>

                        <md-card-actions>
                            <md-button :disabled="submitting" class="md-raised md-dense md-primary mr-3 mb-3" @click="initPayment">
                                Subscribe
                            </md-button>
                        </md-card-actions>
                    </md-ripple>
                </md-card>
            </div>
        </modal>

        <!--        end modals-->

        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">
                        Membership Subscriptions
                    </div>
                    <div class="float-right">
                        <div
                            class="btn-group"
                            role="group"
                            aria-label="Basic example"
                        >
                            <md-button class="md-raised md-dense md-primary" @click="subscriptionModal"> Add
                                Subscription
                            </md-button>
                            <md-button
                                class="md-fab md-mini bg-edit md-raised">
                                <md-icon>filter_list</md-icon>
                            </md-button>
                        </div>
                    </div>
                </md-card-header>

                <md-card-content>
                    <div class="mt-4">
                        <md-table>
                            <md-table-row>
                                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                <md-table-head class="text-center">Plan Name</md-table-head>
                                <md-table-head class="text-center">Plan Validity</md-table-head>
                                <md-table-head class="text-center">Start Date</md-table-head>
                                <md-table-head class="text-center">Expiry Date</md-table-head>
                                <md-table-head class="text-center">Status</md-table-head>
                                <md-table-head class="text-center">Actions</md-table-head>
                            </md-table-row>

                            <md-table-row v-for="row in subscriptions" :key="row.id">
                                <md-table-cell class="text-center" md-numeric>{{ row.id }}</md-table-cell>
                                <md-table-cell class="text-center"> {{ row.subscription_plan.name }}</md-table-cell>
                                <md-table-cell class="text-center"> {{ row.subscription_plan.validity }} days</md-table-cell>
                                <md-table-cell class="text-center">{{
                                        row.created_at | moment("dddd, Do MMMM YYYY")
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{
                                        row.expiry_date | moment("dddd, Do MMMM YYYY")
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <md-chip :class="getStatus(row.status)"> {{ row.status }}</md-chip>
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <div
                                        class="btn-group"
                                        role="group"
                                        aria-label="Basic example"
                                    >
                                        <md-button @click="showPaymentDetails(row.payment)"
                                                   class="md-fab md-mini md-raised bg-edit">
                                            <md-icon>payment</md-icon>
                                            <md-tooltip md-direction="bottom"> View Payment Details</md-tooltip>
                                        </md-button>
                                    </div>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>

                <md-card-actions>
                    <pagination
                        :data="pagination"
                        @pagination-change-page="loadSubscriptions"
                        page="1"
                    ></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>

<script>
export default {
    name: "Subscriptions",

    data() {
        return {
            form: new Form({
                name: "",
            }),
            subscription_plan_id: null,
            subscriptions: {},
            subscription_plans: {},
            payment_details: {},
            pagination: {},
            api_path: "/api/individuals/organizations/" + this.$route.params.id + "/subscriptions",
            submitting: false,
        };
    },

    methods: {
        loadSubscriptions(page = 1) {
            this.$spinner.show();
            axios
                .get(this.api_path + "?page=" + page)
                .then((response) => {
                    this.prepPagination(response.data);
                    this.subscriptions = response.data.data;
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        getStatus(status) {
            if (status == 'active' || status == 'success') {
                return "bg-success";
            } else {
                return "md-accent";
            }
        },
        showPaymentDetails(data) {
            this.payment_details = data;
            this.$modal.show('payment_details');
        },

        clearPaymentModal(event) {
            this.payment_details = null;
        },

        subscriptionModal() {
            this.$modal.show('subscription');
        },

        getSubscriptionPlans() {
            this.$spinner.show();
            axios
                .get("/api/individuals/organizations/" + this.$route.params.id + "/plans")
                .then((response) => {
                    this.subscription_plans = response.data.data;
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        initPayment() {
            if (!this.subscription_plan_id) {
                this.$notify({
                    type: "warn",
                    text: "Please select a Subscription Plan",
                });
            } else {
                this.$spinner.show();
                this.submitting = true;

                let data = {
                    subscription_plan_id: this.subscription_plan_id,
                };

                axios
                    .post("/api/individuals/organizations/subscription/pay", data)
                    .then((response) => {
                        this.submitting = false;
                        this.$notify({
                            type: response.data.status ? "success" : "warn",
                            text: response.data.message,
                        });

                        if (response.data.status && response.data.data.link) {
                            window.location.href = response.data.data.link;
                        }
                    })
                    .catch((error) => {
                        this.submitting = false;
                        this.$notify({
                            type: "error",
                            text: error.response.data.message,
                        });
                        // console.log(error.response.data)
                    })
                    .finally(() => {
                        this.$spinner.hide();
                    });
            }
        },

    },

    mounted() {
        this.loadSubscriptions();
        this.getSubscriptionPlans();
    },
}
</script>

<style scoped>

</style>
