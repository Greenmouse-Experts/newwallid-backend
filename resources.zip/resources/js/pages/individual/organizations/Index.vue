<template>
    <div>
        <md-card md-with-hover class="round-card mt-4">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">My Joined Organization</div>

                        <div class="col-md-4" style="float: right">
                            <md-field>
                                <label>Type here to Search!</label>
                                <md-input v-model="search" v-on:input="debounceSearch"></md-input>
                                <md-icon>search</md-icon>
                                <span class="md-helper-text">Input Company Wall-ID username</span>
                            </md-field>
                        </div>

                </md-card-header>

                <md-card-content>
                    <div style="margin-top: 61px">
                        <md-table>
                            <md-table-row>
                                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                <md-table-head class="text-center">Name</md-table-head>
                                <md-table-head class="text-center">Phone</md-table-head>
                                <md-table-head class="text-center">Date Joined</md-table-head>
                                <md-table-head class="text-center">Status</md-table-head>
                                <md-table-head class="text-center">Subscription Status</md-table-head>
                                <md-table-head class="text-center">Actions</md-table-head>
                            </md-table-row>

                            <md-table-row v-for="(row, index) in joined_organizations" :key="row.id">
                                <md-table-cell class="text-center" md-numeric>{{
                                        row.id
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center"
                                >{{ row.organization.name }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{
                                        row.organization.phone
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{
                                        row.updated_at | moment("from", "now")
                                    }}
                                </md-table-cell>

                                <md-table-cell class="text-center">
                                    <md-chip :class="getStatus(row.status)">{{
                                            row.status
                                        }}
                                    </md-chip>
                                </md-table-cell>

                                <md-table-cell class="text-center">
                                    <md-chip v-if="row.subscription" :class="getStatus(row.subscription.status)">{{
                                            row.subscription.status
                                        }}
                                    </md-chip>

                                    <md-chip v-if="!row.subscription"> No Subscription</md-chip>

                                </md-table-cell>

                                <md-table-cell class="text-center">
                                    <div
                                        class="btn-group"
                                        role="group"
                                        aria-label="Basic example"
                                    >
                                        <md-button
                                            class="md-fab md-mini bg-edit md-raised"
                                            :to="$route.path + '/' + row.organization.id + '/subscriptions' "
                                        >
                                            <md-icon>autorenew</md-icon>
                                            <md-tooltip md-direction="bottom">View Subscription Details</md-tooltip>
                                        </md-button>


                                        <md-button
                                            class="md-fab md-mini md-accent">
                                            <md-icon>logout</md-icon>
                                            <md-tooltip md-direction="bottom">Leave Organization</md-tooltip>
                                        </md-button>

                                    </div>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>

                <md-card-actions>
                    <pagination
                        :data="pagination"
                        @pagination-change-page="loadJoinedOrganization"
                        page="1"
                    ></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>

<script>
export default {
    name: "UserOrganizations",

    data() {
        return {
            form: new Form({
                name: "",
            }),

            search:"",
            joined_organizations: [],
            pagination: {},
            api_path: "/api/individuals/organizations",
        };
    },

    methods: {
        loadJoinedOrganization(page = 1) {
            this.$spinner.show();
            axios
                .get(this.api_path + "?page=" + page)
                .then((response) => {
                    // console.log(response);
                    this.prepPagination(response.data);
                    this.joined_organizations = response.data.data;
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        getStatus(data) {
            if (data == "active") {
                return "bg-success";
            } else {
                return "md-accent";
            }
        },


        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        debounceSearch: _.debounce(function (){
            if (this.search == ""){
                this.api_path = "/api/individuals/organizations";
                this.loadJoinedOrganization();
            }else{
             this.initSearch(this.search);
            }
        }, 500),

        initSearch(query){
            this.api_path = "/api/individuals/organizations/" + query;
            this.loadJoinedOrganization();
        }


    },

    mounted() {
        this.loadJoinedOrganization();
    },
};
</script>
