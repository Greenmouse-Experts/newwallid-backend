<template>
    <div>
        <form @submit.prevent="update" @keydown="form.onKeydown($event)">

            <md-card md-with-hover class="round-card">
                <md-ripple>
                    <md-card-header>
                        <div class="md-title">Edit and Update Profile</div>
                        <!--                        <div class="md-subhead">It also have a ripple</div>-->
                    </md-card-header>

                    <md-card-content>
                        <div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <md-field :class="getValidationClass('firstname')">
                                        <md-icon>article</md-icon>
                                        <label>Firstname</label>
                                        <md-input v-model="form.firstname"></md-input>
                                        <div
                                            v-if="form.errors.has('firstname')"
                                            class="md-error"
                                            v-html="form.errors.get('firstname')"
                                        />
                                        <span class="md-helper-text">Firstname</span>
                                    </md-field>
                                </div>

                                <div class="col-md-6">
                                    <md-field :class="getValidationClass('lastname')">
                                        <md-icon>article</md-icon>
                                        <label>Lastname</label>
                                        <md-input v-model="form.lastname"></md-input>
                                        <div
                                            v-if="form.errors.has('lastname')"
                                            class="md-error"
                                            v-html="form.errors.get('lastname')"
                                        />
                                        <span class="md-helper-text">Lastname</span>
                                    </md-field>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <md-field :class="getValidationClass('email')">
                                        <md-icon>email</md-icon>
                                        <label>Email</label>
                                        <md-input v-model="form.email" disabled=""></md-input>
                                        <div
                                            v-if="form.errors.has('email')"
                                            class="md-error"
                                            v-html="form.errors.get('email')"
                                        />
                                        <span class="md-helper-text">Email</span>
                                    </md-field>
                                </div>

                                <div class="col-md-6">

                                    <md-field :class="getValidationClass('phone')">
                                        <md-icon>dialpad</md-icon>
                                        <label>Phone</label>
                                        <md-input v-model="form.phone" disabled=""></md-input>
                                        <div
                                            v-if="form.errors.has('phone')"
                                            class="md-error"
                                            v-html="form.errors.get('phone')"
                                        />
                                        <span class="md-helper-text">Phone</span>
                                    </md-field>
                                </div>
                            </div>
                        </div>
                    </md-card-content>

                </md-ripple>
            </md-card>

            <md-card md-with-hover class="round-card mt-3 mb-3">
                <md-ripple>

                    <md-card-content>
                        <div>
                            <div class="row mb-4">
                                <div class="col-md-6 mb-4">
                                    <md-field :class="getValidationClass('dob')">
                                        <md-icon>article</md-icon>
                                        <label>Date of Birth</label>
                                        <md-input v-model="form.dob" type="date"></md-input>
                                        <div
                                            v-if="form.errors.has('dob')"
                                            class="md-error"
                                            v-html="form.errors.get('dob')"
                                        />
                                        <span class="md-helper-text">Date of Birth</span>
                                    </md-field>
                                </div>

                                <div class="col-md-6">
                                    <md-field :class="getValidationClass('image')">
                                        <label>Profile Picture</label>
                                        <md-file @change="handleimage" accept="image/*"/>
                                        <div
                                            v-if="form.errors.has('image')"
                                            class="md-error"
                                            v-html="form.errors.get('image')"
                                        />
                                        <span class="md-helper-text">Leave blank if you want to retain the old image</span
                                        >
                                    </md-field>
                                </div>

                                <div class="col-md-12">
                                    <md-field :class="getValidationClass('bio')">
                                        <label>BIO</label>
                                        <md-textarea v-model="form.bio"></md-textarea>
                                        <div
                                            v-if="form.errors.has('bio')"
                                            class="md-error"
                                            v-html="form.errors.get('bio')"
                                        />
                                        <md-icon>description</md-icon>
                                    </md-field>
                                </div>

                            </div>

                            <div class="text-right">
                                <md-button class="md-raised md-dense md-primary" type="submit">Update</md-button>
                            </div>

                        </div>
                    </md-card-content>

                </md-ripple>
            </md-card>

        </form>
    </div>
</template>

<script>
export default {
    name: 'UpdateProfile',
    data() {
        return {
            user: null,
            form: new Form({
                firstname: '',
                lastname: '',
                dob: '',
                bio: '',
                email: '',
                phone: '',
                image: ''
            })
        }
    },

    methods: {
        getValidationClass(fieldName) {
            const field = this.form.errors.has(fieldName);
            if (field) {
                return "md-invalid";
            }
        },

        getUser(){
            axios.get("/api/individuals/getUser").then((response) => {
                this.user = response.data.data;
                this.populate()
                // console.log(response.data.data);
            });
        },

        update() {
            this.form.patch('/api/individuals')
                .then(response => {
                    this.$store.dispatch('user/profile');
                    this.$notify({
                        type: (response.data.status) ? 'success' : 'warn',
                        text: response.data.message
                    });

                })
                .catch(e => {
                    if (e.response.status == 422) {
                        this.form.errors.set(e.response.data.error);
                        console.log("422", e.response);
                    }

                    this.$notify({
                        type: 'error',
                        text: e.response.data.message
                    })
                })
                .finally(() => {
                    this.$spinner.hide();
                })
            // console.log('Data', this.form);
        },

        handleimage(event) {
            let file = event.target.files[0];
            //console.log(form)
            let reader = new FileReader();
            reader.onload = (event) => {
                this.form.image = event.target.result;
                console.log(event.target.result);
            };
            reader.readAsDataURL(file);
        },

        populate() {
            if (this.user) {
                this.form.firstname = this.user.details.firstname;
                this.form.lastname = this.user.details.lastname;
                this.form.dob = this.user.details.dob;
                this.form.bio = this.user.details.bio;
                this.form.email = this.user.email;
                this.form.phone = this.user.details.phone;
                this.form.image = this.user.details.image;
            }
        }
    },

    mounted() {
        this.getUser();
    }
}
</script>
