<template>
    <div>

        <md-card md-with-hover class="mb-4 round-card">
            <md-ripple>

                <md-card-content>
                    <div>
                        <md-avatar class="md-large" v-if="user.profile.details.image">
                            <img :src="getProfileImage(user.profile.details.image)"
                                 alt="Image">
                        </md-avatar>

                        <md-avatar class="md-large" v-if="!user.profile.details.image">
                            <img :src=" '/images/user.png' "
                                 alt="Image">
                        </md-avatar>

                        <span class="px-2" v-if="user && user.profile">
					{{ user.profile.details.name}}
				</span>


                    </div>
                </md-card-content>

            </md-ripple>
        </md-card>

        <md-card md-with-hover class="mb-4 round-card">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">Profile</div>
                </md-card-header>
                <md-card-content>
                    <diV>
                        <div class="row">
                            <p class="col">
                                <span class="small text-muted">Company Wall - ID Unique ID</span> <br>
                                <span class="font-weight-bold">
							{{ user.profile.details.id_card_number }}
						</span>
                            </p>

                        </div>
                        <div class="row">
                            <p class="col">
                                <span class="small text-muted">Company Name</span> <br>
                                <span class="font-weight-bold">
							{{ user.profile.details.name }}
						</span>
                            </p>

                        </div>

                        <div class="row">
                            <p class="col">
                                <span class="small text-muted">Company Email</span> <br>
                                <span class="font-weight-bold">
							{{ user.profile.email }}
						</span>
                            </p>

                            <p class="col">
                                <span class="small text-muted">Phone</span> <br>
                                <span class="font-weight-bold">
							{{ user.profile.details.phone }}
						</span>
                            </p>
                        </div>

                        <div class="row">
                            <p class="col">
                                <span class="small text-muted">Company Address</span> <br>
                                <span class="font-weight-bold">
							{{ user.profile.details.address }}
						</span>
                            </p>

                        </div>

                        <div class="text-right">
                            <md-button :to="{name: 'update-organization-profile'}" class="md-dense md-primary md-raised">
                                Edit
                            </md-button>
                        </div>
                    </diV>
                </md-card-content>

            </md-ripple>
        </md-card>



    </div>
</template>

<script>
export default {
    name: 'UserProfile',
    data() {
        return {
            user: null
        }
    },

    methods: {
        getProfileImage(image) {
            if (image == null) {
                return "";
            } else {
                return "/profile_picture/organization/" + image;
            }

        }
    },

    mounted() {
        this.user = this.$store.state.user;
    }
}
</script>
