<template>
    <div>
        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">Membership Requests</div>
                    <!-- <div class="md-subhead">It also have a ripple</div> -->
                </md-card-header>

                <md-card-content>
                    <md-table>
                        <md-table-row>
                            <md-table-head class="text-center" md-numeric>ID</md-table-head>
                            <md-table-head class="text-center">Full Name</md-table-head>
                            <md-table-head class="text-center">Phone</md-table-head>
                            <md-table-head class="text-center">Date Sent</md-table-head>
                            <md-table-head class="text-center">Status</md-table-head>
                            <md-table-head class="text-center">Action</md-table-head>
                        </md-table-row>

                        <md-table-row
                            v-for="(row, index) in membership_requests"
                            :key="row.id"
                        >
                            <md-table-cell class="text-center" md-numeric>
                                {{ row.id }}
                            </md-table-cell>
                            <md-table-cell class="text-center text-capitalize"
                            >{{ row.individual.firstname }} {{ row.individual.lastname }}
                            </md-table-cell>
                            <md-table-cell class="text-center">{{
                                    row.individual.phone
                                }}
                            </md-table-cell>
                            <md-table-cell class="text-center">
                                {{ row.created_at | moment("from", "now") }}
                            </md-table-cell>
                            <md-table-cell class="text-center">
                                <md-chip :class="getStatus(row.status)">
                                    {{ row.status }}
                                </md-chip>
                            </md-table-cell>
                            <md-table-cell class="text-center">
                                <div class="btn-group" role="group" aria-label="Basic example">
                                    <md-button
                                        v-if="row.status == 'pending'"
                                        class="md-dense md-raised bg-success text-white"
                                        @click="approve(row.id)"
                                    >
                                        Approve
                                    </md-button>

                                    <md-button
                                        v-if="row.status == 'pending'"
                                        class="md-dense md-raised md-accent text-white"
                                        @click="decline(row.id)"
                                    >
                                        Decline
                                    </md-button>

                                    <md-button
                                        :to="$route.path + '/' + row.id"
                                        class="md-dense md-raised md-primary"
                                    >
                                        View
                                    </md-button>
                                </div>
                            </md-table-cell>
                        </md-table-row>
                    </md-table>
                </md-card-content>

                <md-card-actions>
                    <pagination
                        :data="pagination"
                        @pagination-change-page="loadRequests"
                        page="1"
                    ></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>

<script>
export default {
    data() {
        return {
            pagination: {},
            membership_requests: [],
            filter: "All",
            api_path: "/api/organizations/members/requests",
        };
    },

    methods: {
        loadRequests(page = 1) {
            axios
                .get("/api/organizations/members/requests/get" + "?page=" + page)
                .then((response) => {
                    this.prepPagination(response.data);
                    this.membership_requests = response.data.data;
                })
                .catch((e) => {
                    this.$notify({
                        text: e.response.data.message,
                    });
                });
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        approve(reqid) {
            this.$confirm({
                message: "Approve Membership Request?",
                button: {
                    no: "No",
                    yes: "Yes",
                },
                callback: (confirm) => {
                    if (confirm) {
                        this.doApprove(reqid);
                    }
                },
            });
        },

        decline(reqid) {
            this.$confirm({
                message: "Decline Membership Request?",
                button: {
                    no: "No",
                    yes: "Yes",
                },
                callback: (confirm) => {
                    if (confirm) {
                        this.doDecline(reqid);
                    }
                },
            });
        },

        doApprove(id) {
            this.$spinner.show();
            axios
                .get(this.api_path + "/approve/" + id)
                .then((response) => {
                    console.log(response);
                    this.$notify({
                        type: response.data.status ? "success" : "warn",
                        text: response.data.message,
                    });
                    this.loadRequests();
                })
                .catch((e) => {
                    this.$notify({
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        doDecline(id) {
            this.$spinner.show();
            axios
                .get(this.api_path + "/decline/" + id)
                .then((response) => {
                    console.log(response);
                    this.$notify({
                        type: response.data.status ? "success" : "warn",
                        text: response.data.message,
                    });
                    this.loadRequests();
                })
                .catch((e) => {
                    this.$notify({
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        getStatus(data) {
            if (data == "pending") {
                return "md-primary";
            } else if (data == "declined") {
                return "md-accent";
            } else {
                return "bg-success";
            }
        },
    },

    mounted() {
        this.loadRequests();
    },
};
</script>
