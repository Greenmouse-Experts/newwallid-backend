<template>
  <div>
    <md-card md-with-hover class="round-card">
      <md-ripple>
        <md-card-header> </md-card-header>

        <md-card-content>
          <div v-if="member">
            <img src="/images/user.png" style="width: 50px; height: 50px" />
            <span class="px-2">{{
              member.individual.firstname + " " + member.individual.lastname
            }}</span>
          </div>
        </md-card-content>
      </md-ripple>
    </md-card>

    <md-card md-with-hover class="round-card mt-5">
      <md-ripple>
        <md-card-header> </md-card-header>

        <md-card-content>
          <div v-if="member">
            <div class="row">
              <div class="col-md-6">
                <div class="mb-4">Personal Details</div>

                <p class="mb-3">
                  <span class="small text-muted">Firstname</span> <br />
                  <span class="h4 text-capitalize">{{
                    member.individual.firstname
                  }}</span>
                </p>

                <p class="mb-3">
                  <span class="small text-muted">Lastname</span> <br />
                  <span class="h4 text-capitalize">{{
                    member.individual.lastname
                  }}</span>
                </p>

                <p class="mb-3">
                  <span class="small text-muted">DOB</span> <br />
                  <span class="h4">
                    {{ member.individual.dob }}
                  </span>
                </p>

                <p>
                  <span class="small text-muted">Bio</span> <br />
                  <span class="h4">
                    {{ member.individual.bio }}
                  </span>
                </p>
              </div>

              <div class="col-md-6" v-if="member.subscription">
                <div class="mb-4">Subscription Details</div>

                <p class="mb-3">
                  <span class="small text-muted">Subscription Plan</span> <br />
                  <span class="h4">
                    {{ member.subscription.subscription_plan.name }}
                  </span>
                </p>

                <p class="mb-3">
                  <span class="small text-muted">Subscription Plan Price</span>
                  <br />
                  <span class="h4">
                    {{ member.subscription.subscription_plan.price }}
                  </span>
                </p>

                <p class="mb-3">
                  <span class="small text-muted"
                    >Subscription Plan Validity</span
                  >
                  <br />
                  <span class="h4">
                    {{ member.subscription.subscription_plan.validity }}
                  </span>
                </p>

                <p class="mb-3">
                  <span class="small text-muted"
                    >Subscription Created / Start Date</span
                  >
                  <br />
                  <span class="h4">
                    {{
                      member.subscription.created_at
                        | moment("dddd, MMMM Do YYYY")
                    }}
                  </span>
                </p>

                <p class="mb-3">
                  <span class="small text-muted">Subscription Expiry Date</span>
                  <br />
                  <span class="h4">
                    {{
                      member.subscription.expiry_date
                        | moment("dddd, MMMM Do YYYY")
                    }}
                  </span>
                </p>

                <p class="mb-3">
                  <span class="small text-muted">Subscription Status</span>
                  <br />
                  <span class="h4">
                    <md-chip :class="getStatus(member.subscription.status)">
                      {{ member.subscription.status }}</md-chip
                    >
                  </span>
                </p>
              </div>

              <div class="col-md-6" v-if="!member.subscription">
                <div class="mb-4">Subscription Details</div>

                <div class="text-center h4">NO CURRENT SUBSCRIPTION</div>
              </div>
            </div>
          </div>
        </md-card-content>
      </md-ripple>
    </md-card>
  </div>
</template>

<script>
export default {
  name: "MemberProfile",
  data() {
    return {
      member: null,
    };
  },
  methods: {
    getStatus(status) {
      if (status == "active") {
        return "bg-success";
      } else {
        return "md-accent";
      }
    },

    getMember(id) {
      this.$spinner.show();
      axios
        .get("/api/organizations/members/" + id)
        .then((response) => {
          console.log("member", response);
          this.member = response.data.data;
          this.$notify({
            type: response.data.status ? "success" : "warn",
            text: response.data.message,
          });
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },

    approve(id) {
      this.$confirm({
        message: "Approve?",
        button: {
          no: "No",
          yes: "Yes",
        },
        callback: (confirm) => {
          if (confirm) {
            this.doApprove(id);
          }
        },
      });
    },

    doApprove(id) {
      this.$spinner.show();
      axios
        .get("/api/organizations/members/" + id + "/approve")
        .then((response) => {
          this.$notify({
            type: "success",
            text: response.data.message,
          });
        })
        .catch((e) => {
          this.$notify({
            type: "success",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },
  },
  mounted() {
    this.getMember(this.$route.params.id);
  },
};
</script>
