<template>
  <div>
    <md-card md-with-hover class="round-card">
      <md-ripple>
        <md-card-header>
          <div class="md-title">Membership Request Information</div>
          <!-- <div class="md-subhead">It also have a ripple</div> -->
        </md-card-header>

        <md-card-content>
          <div class="row">
            <div class="col-md-6">
              <md-card md-with-hover class="round-card">
                <md-ripple>
                  <md-card-header>
                    <div class="md-title">FROM</div>
                  </md-card-header>

                  <md-card-content>
                    <div class="text-center">
                      <p class="text-capitalize">
                        Name : {{ request_info.individual.firstname }}
                        {{ request_info.individual.lastname }}
                      </p>
                      <p>ID : {{ request_info.individual.id }}</p>

                      <p>Phone Number : {{ request_info.individual.phone }}</p>
                      <p>Email : {{ request_info.individual.user.email }}</p>
                      <p>Username : {{ request_info.individual.user.name }}</p>
                    </div>
                  </md-card-content>
                </md-ripple>
              </md-card>
            </div>

            <div class="col-md-6">
              <md-card md-with-hover class="round-card">
                <md-ripple>
                  <md-card-header>
                    <div class="md-title">TO</div>
                  </md-card-header>

                  <md-card-content>
                    <div class="text-center">
                      <p class="text-capitalize">
                        Name : {{ request_info.organization.name }}
                      </p>
                      <p>ID : {{ request_info.organization.id }}</p>

                      <p>
                        Phone Number : {{ request_info.organization.phone }}
                      </p>
                      <p>Email : {{ request_info.organization.user.email }}</p>
                      <p>
                        Username : {{ request_info.organization.user.name }}
                      </p>
                    </div>
                  </md-card-content>
                </md-ripple>
              </md-card>
            </div>

            <div class="col-md-12">
              <div class="text-center mt-4">
               Status :  <md-chip :class="getStatus(request_info.status)">
                  {{ request_info.status }}
                </md-chip>
              </div>
            </div>
          </div>
        </md-card-content>

        <md-card-actions>
          <pagination
            :data="pagination"
            @pagination-change-page="loadRequests"
            page="1"
          ></pagination>
        </md-card-actions>
      </md-ripple>
    </md-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      request_info: [],
      api_path: "/api/organizations/members/requests",
    };
  },

  methods: {
    getRequestInfo(id) {
      axios
        .get(this.api_path + "/" + id)
        .then((response) => {
          this.$notify({
            text: response.data.message,
          });
          this.request_info = response.data.data;
        })
        .catch((e) => {
          this.$notify({
            text: e.response.data.message,
          });
        });
    },
    getStatus(data) {
      if (data == "pending") {
        return "md-primary";
      } else if (data == "declined") {
        return "md-accent";
      } else {
        return "bg-success";
      }
    },
  },

  mounted() {
    this.getRequestInfo(this.$route.params.id);
  },
};
</script>
