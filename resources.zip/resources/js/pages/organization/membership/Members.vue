<template>
    <div>
        <modal name="member-modal" :adaptive="true" :height="350">
            <div class="card h-100">
                <div class="card-body">
                    <p class="card-title">User Information:</p>

                    <p v-if="user">
                        Fullname:
                        <b>{{ user.details.firstname + " " + user.details.lastname }}</b>
                    </p>

                    <p v-if="user">
                        Email: <b>{{ user.email }}</b>
                    </p>

                    <p class="mb-3" v-if="user">
                        Phone: <b>{{ user.details.phone }}</b>
                    </p>

                    <div class="px-1">
                        <md-field>
                            <label>Membership Subscription Plan</label>
                            <md-select v-model="subscription_plan_id" name="movie" id="movie">
                                <md-option
                                    v-for="plan in subscription_plans"
                                    :key="plan.id"
                                    :value="plan.id"
                                >{{ plan.name }}
                                </md-option
                                >
                            </md-select>
                        </md-field>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button class="btn btn-primary px-3" @click="addMember">
                        Add and approve
                    </button>
                </div>
            </div>
        </modal>

        <md-card md-with-hover class="round-card mb-5">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">Add Member</div>

                </md-card-header>
                <div></div>
                <md-card-content>
                    <div>
                        <form
                            class="form-row"
                            @submit.prevent="getUser"
                            @keydown="form.onKeydown($event)"
                        >
                            <div class="col-md-8">
                                <md-field>
                                    <md-icon>article</md-icon>
                                    <label>Username</label>
                                    <md-input v-model="form.name" required></md-input>
                                    <span class="md-helper-text">Wall-ID Username</span>
                                </md-field>
                                <div
                                    v-if="form.errors.has('name')"
                                    v-html="form.errors.get('name')"
                                />
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <md-button
                                    class="md-dense md-raised md-primary px-3"
                                    type="submit"
                                >Fetch User
                                </md-button
                                >
                            </div>
                        </form>
                    </div>
                </md-card-content>
            </md-ripple>
        </md-card>

        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">{{ filter }} Members</div>

                    <div class="float-right">
                        <div
                            class="btn-group"
                            role="group"
                            aria-label="Basic example"
                        >

                            <md-menu md-size="auto">
                                <md-button md-menu-trigger class="md-fab md-mini bg-edit md-raised">
                                    <md-icon>filter_list</md-icon>
                                </md-button>

                                <md-menu-content>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getAllMember">
                                            All Members
                                        </md-button>
                                    </md-menu-item>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getActiveMember">
                                            All Active Members
                                        </md-button>
                                    </md-menu-item>

                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getUnactiveMember">
                                            All Unactive Member
                                        </md-button>
                                    </md-menu-item>

                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="openSearchModal()">
                                            Search By Username
                                        </md-button>
                                    </md-menu-item>
                                </md-menu-content>
                            </md-menu>

                        </div>
                    </div>
                </md-card-header>

                <md-card-content>
                    <div class="mt-4">
                        <md-table>
                            <md-table-row>
                                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                <md-table-head class="text-center">Full Name</md-table-head>
                                <md-table-head class="text-center">Phone</md-table-head>
                                <md-table-head class="text-center">Email</md-table-head>
                                <md-table-head class="text-center">Date Joined</md-table-head>
                                <md-table-head class="text-center">status</md-table-head>
                                <md-table-head class="text-center">Action</md-table-head>
                            </md-table-row>

                            <md-table-row v-for="(row, index) in members" :key="row.id">
                                <md-table-cell class="text-center" md-numeric>
                                    {{ row.id }}
                                </md-table-cell>
                                <md-table-cell class="text-center text-capitalize"
                                >{{ row.individual.firstname }}
                                    {{ row.individual.lastname }}
                                </md-table-cell
                                >
                                <md-table-cell class="text-center">
                                    {{ row.individual.phone }}
                                </md-table-cell
                                >
                                <md-table-cell class="text-center">{{
                                        row.individual.user.email
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{
                                        row.created_at | moment("from", "now")
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <md-chip :class="getStatus(row.status)">
                                        {{ row.status }}
                                    </md-chip>
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <md-button
                                        v-if="row.status == 'unactive'"
                                        class="md-fab md-mini bg-success"
                                        @click="activate(row.id)"
                                    >
                                        <md-icon>thumb_up</md-icon>
                                        <md-tooltip md-direction="bottom"
                                        >Activate / Un-Suspend Member
                                        </md-tooltip
                                        >
                                    </md-button>
                                    <md-button
                                        v-if="row.status == 'active'"
                                        class="md-fab md-mini"
                                        @click="suspend(row.id)"
                                    >
                                        <md-icon>thumb_down</md-icon>
                                        <md-tooltip md-direction="bottom"
                                        >De-activate / Suspend Member
                                        </md-tooltip
                                        >
                                    </md-button>
                                    <md-button
                                        :to="'/organization/members/' + row.id"
                                        class="md-fab md-mini bg-edit"
                                    >
                                        <md-icon>visibility</md-icon>
                                        <md-tooltip md-direction="bottom"
                                        >View Member Details
                                        </md-tooltip
                                        >
                                    </md-button>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>

                <md-card-actions>
                    <pagination
                        :data="pagination"
                        @pagination-change-page="loadMembers"
                        page="1"
                    ></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>

<script>
export default {
    data() {
        return {
            api_path: "/api/organizations/members",
            filter: "All",
            pagination: {},
            form: new Form({
                name: "",
            }),

            user: null,
            members: [],
            subscription_plans: [],
            subscription_plan_id: null,
        };
    },

    methods: {
        loadMembers(page = 1) {
            this.$spinner.show();
            axios
                .get(this.api_path + "?page=" + page)
                .then((response) => {
                    this.prepPagination(response.data);
                    this.members = response.data.data;
                    this.$notify({
                        type: response.data.status ? "success" : "warn",
                        text: response.data.message,
                    });
                })
                .catch((e) => {
                    this.$spinner({
                        type: "error",
                        text: e.resonse.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        addMember() {
            this.$modal.hide("member-modal");
            if (this.user.type == "individual") {
                if (this.subscription_plan_id) {
                    let data = {
                        individual_id: this.user.details.id, //individual id
                        subscription_plan_id: this.subscription_plan_id,
                    };

                    this.$spinner.show();
                    axios
                        .post(this.api_path + "/add_and_approve", data)
                        .then((response) => {
                            this.$notify({
                                type: "success",
                                text: response.data.message,
                            });
                            this.loadMembers();
                        })
                        .catch((e) => {
                            this.$notify({
                                type: "error",
                                text: e.response.data.message,
                            });
                        })
                        .finally(() => {
                            this.$spinner.hide();
                        });
                } else {
                    this.$notify({
                        type: "error",
                        text: "Select Membership Subscription Plan",
                    });
                }
            } else {
                this.$notify({
                    type: "error",
                    text: "You Cant add an Oganization as a member",
                });
            }
        },

        activate(id) {
            this.$confirm({
                message: "Are you sure you want to Activate / Un-Suspend this Member?",
                button: {
                    no: "No",
                    yes: "Yes",
                },
                callback: (confirm) => {
                    if (confirm) {
                        this.doActivate(id);
                    }
                },
            });
        },

        doActivate(id) {
            this.$spinner.show();
            axios
                .get(this.api_path + "/activate/" + id)
                .then((response) => {
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                    this.loadMembers();
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        suspend(id) {
            this.$confirm({
                message:
                    "Are you really sure you want to De-Activate / Suspend this Member?",
                button: {
                    no: "No",
                    yes: "Yes",
                },
                callback: (confirm) => {
                    if (confirm) {
                        this.doSuspend(id);
                    }
                },
            });
        },

        doSuspend(id) {
            this.$spinner.show();
            axios
                .get(this.api_path + "/deactivate/" + id)
                .then((response) => {
                    this.loadMembers();
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                })
                .catch((e) => {
                    this.$notify({
                        type: "success",
                        text: eresponse.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        getStatus(data) {
            if (data == "unactive") {
                return "md-accent";
            } else {
                return "bg-success";
            }
        },

        getUser() {
            this.$spinner.show();
            axios
                .get("/api/users/username/" + this.form.name)
                .then((response) => {
                    console.log(response);
                    if (response.data.status) {
                        this.$notify({
                            type: "success",
                            text: response.data.message,
                        });

                        this.user = response.data.data;
                        this.$modal.show("member-modal");
                    } else {
                        this.$notify({
                            type: "error",
                            text: response.data.message,
                        });
                    }
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        loadSubscription_plans() {
            axios
                .get("/api/organizations/subscriptions/plans/byOrg")
                .then((response) => {
                    this.subscription_plans = response.data.data;
                })
                .catch((e) => {
                })
                .finally(() => {
                });
        },

        getAllMember(){
            this.api_path = "/api/organizations/members";
            this.loadMembers();
            this.filter = "All";
        },

        getActiveMember(){
            this.api_path = "/api/organizations/members/active";
            this.loadMembers();
            this.filter = "All Active";
        },

        getUnactiveMember(){
            this.api_path = "/api/organizations/members/unactive";
            this.loadMembers();
            this.filter = "All Unactive";
        },

        openSearchModal(){
            
        }
    },

    mounted() {
        this.loadMembers();
        this.loadSubscription_plans();
    },
};
</script>
