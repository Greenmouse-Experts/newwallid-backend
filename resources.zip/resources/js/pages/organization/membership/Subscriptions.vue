<template>
    <div>
        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">Membership Subscriptions</div>
                    <div class="float-right">
                        <div
                            class="btn-group"
                            role="group"
                            aria-label="Basic example"
                        >

                            <md-menu md-size="auto">
                                <md-button md-menu-trigger class="md-fab md-mini bg-edit md-raised">
                                    <md-icon>filter_list</md-icon>
                                </md-button>

                                <md-menu-content>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getAllSubscription">
                                            All Subscriptions
                                        </md-button>
                                    </md-menu-item>
                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getActiveSubscription">
                                            All Active Subscriptions
                                        </md-button>
                                    </md-menu-item>

                                    <md-menu-item>
                                        <md-button class="md-dense md-raised" @click="getExpiredSubscription">
                                            All Expired Subscriptions
                                        </md-button>
                                    </md-menu-item>
                                </md-menu-content>
                            </md-menu>

                        </div>
                    </div>
                </md-card-header>

                <md-card-content>
                    <div class="mt-4">
                        <md-table>
                            <md-table-row>
                                <md-table-head md-numeric>ID</md-table-head>
                                <md-table-head>User Name</md-table-head>
                                <md-table-head>User Email</md-table-head>
                                <md-table-head>Start Date</md-table-head>
                                <md-table-head>Expiry Date</md-table-head>
                                <md-table-head>Status</md-table-head>
                            </md-table-row>

                            <md-table-row v-for="(row, index) in subscriptions" :key="row.id">
                                <md-table-cell md-numeric>{{ row.id }}</md-table-cell>
                                <md-table-cell
                                >{{ row.individual.firstname }}
                                    {{ row.individual.lastname }}
                                </md-table-cell
                                >
                                <md-table-cell>{{ row.individual.user.email }}</md-table-cell>
                                <md-table-cell>
                                    {{
                                        row.created_at | moment("dddd, MMMM Do YYYY")
                                    }}
                                </md-table-cell
                                >
                                <md-table-cell>
                                    {{
                                        row.expiry_date | moment("dddd, MMMM Do YYYY")
                                    }}
                                </md-table-cell
                                >
                                <md-table-cell>
                                    <md-chip :class="getStatus(row.status)"> {{ row.status }}</md-chip>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>

                <md-card-actions>
                    <pagination
                        :data="pagination"
                        @pagination-change-page="loadSubscriptions"
                        page="1"
                    ></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>

<script>
export default {
    data() {
        return {
            subscriptions: [],
            pagination: {},
            filter: "All",
            api_path: "/api/organizations/subscriptions",
        };
    },

    methods: {
        loadSubscriptions(page = 1) {
            this.$spinner.show();
            axios
                .get(this.api_path + "?page=" + page)
                .then((response) => {
                    console.log(response);
                    this.prepPagination(response.data);
                    this.subscriptions = response.data.data;
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                })
                .catch((e) => {
                    console.log("Error", e);
                    this.$notify({
                        type: "error",
                        text: e.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        getStatus(status) {
            if (status == 'active') {
                return "bg-success";
            } else {
                return "md-accent";
            }
        },

        getAllSubscription(){
            this.api_path = "/api/organizations/subscriptions";
            this.loadSubscriptions();
            this.filter = "All";
        },

        getActiveSubscription(){
            this.api_path = "/api/organizations/subscriptions/active";
            this.loadSubscriptions();
            this.filter = "All Active";
        },

        getExpiredSubscription(){
            this.api_path = "/api/organizations/subscriptions/expired";
            this.loadSubscriptions();
            this.filter = "All Expired";
        },
    },

    mounted() {
        this.loadSubscriptions();
    },
};
</script>
