<template>
    <div>
        <form @submit.prevent="updatePassword" @keydown="form.onKeydown($event)">

            <md-card md-with-hover class="round-card">
                <md-ripple>
                    <md-card-header>
                        <div class="md-title">Edit and Update Profile</div>
                        <!--                        <div class="md-subhead">It also have a ripple</div>-->
                    </md-card-header>

                    <md-card-content>
                        <div>

                            <div class="row mb-4">

                                <div class="col-md-6">
                                    <md-field :class="getValidationClass('name')">
                                        <md-icon>article</md-icon>
                                        <label>Company Name</label>
                                        <md-input v-model="form.name"></md-input>
                                        <div
                                            v-if="form.errors.has('name')"
                                            class="md-error"
                                            v-html="form.errors.get('name')"
                                        />
                                        <span class="md-helper-text">Company Name</span>
                                    </md-field>
                                </div>

                                <div class="col-md-6">
                                    <md-field :class="getValidationClass('image')">
                                        <label>Profile Picture</label>
                                        <md-file @change="handleimage" accept="image/*"/>
                                        <div
                                            v-if="form.errors.has('image')"
                                            class="md-error"
                                            v-html="form.errors.get('image')"
                                        />
                                        <span
                                            class="md-helper-text">Leave blank if you want to retain the old image</span
                                        >
                                    </md-field>
                                </div>


                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <md-field :class="getValidationClass('email')">
                                        <md-icon>email</md-icon>
                                        <label>Email</label>
                                        <md-input v-model="form.email" disabled=""></md-input>
                                        <div
                                            v-if="form.errors.has('email')"
                                            class="md-error"
                                            v-html="form.errors.get('email')"
                                        />
                                        <span class="md-helper-text">Email</span>
                                    </md-field>
                                </div>

                                <div class="col-md-6">

                                    <md-field :class="getValidationClass('phone')">
                                        <md-icon>dialpad</md-icon>
                                        <label>Phone</label>
                                        <md-input v-model="form.phone" disabled=""></md-input>
                                        <div
                                            v-if="form.errors.has('phone')"
                                            class="md-error"
                                            v-html="form.errors.get('phone')"
                                        />
                                        <span class="md-helper-text">Phone</span>
                                    </md-field>
                                </div>

                                <div class="col-md-12">

                                    <md-field :class="getValidationClass('address')">
                                        <md-icon>article</md-icon>
                                        <label>Address</label>
                                        <md-input v-model="form.address"></md-input>
                                        <div
                                            v-if="form.errors.has('address')"
                                            class="md-error"
                                            v-html="form.errors.get('address')"
                                        />
                                        <span class="md-helper-text">Address</span>
                                    </md-field>
                                </div>


                            </div>

                            <div class="text-right">
                                <md-button class="md-raised md-dense md-primary" type="submit">Update</md-button>
                            </div>

                        </div>
                    </md-card-content>

                </md-ripple>
            </md-card>

            <md-card md-with-hover class="round-card mt-4">
                <md-ripple>
                    <md-card-header>
                        <div class="md-title">Change Password</div>
                    </md-card-header>

                    <md-card-content>
                        <div>

                            <div class="row mb-4">

                                <div class="col-md-4">
                                    <md-field :class="getValidationClass('current_password')">
                                        <md-icon>article</md-icon>
                                        <label>Current Password</label>
                                        <md-input type="password" v-model="form.current_password"></md-input>
                                        <div
                                            v-if="form.errors.has('current_password')"
                                            class="md-error"
                                            v-html="form.errors.get('current_password')"
                                        />
                                        <span class="md-helper-text">Input your current Password</span>
                                    </md-field>
                                </div>

                                <div class="col-md-4">
                                    <md-field :class="getValidationClass('password')">
                                        <md-icon>article</md-icon>
                                        <label>New Password</label>
                                        <md-input v-model="form.password" type="password"></md-input>
                                        <div
                                            v-if="form.errors.has('password')"
                                            class="md-error"
                                            v-html="form.errors.get('password')"
                                        />
                                        <span
                                            class="md-helper-text">Enter your new Password here</span
                                        >
                                    </md-field>
                                </div>

                                <div class="col-md-4">
                                    <md-field :class="getValidationClass('password_confirmation')">
                                        <md-icon>email</md-icon>
                                        <label>Confirm New Password</label>
                                        <md-input v-model="form.password_confirmation" type="password"></md-input>
                                        <div
                                            v-if="form.errors.has('password_confirmation')"
                                            class="md-error"
                                            v-html="form.errors.get('password_confirmation')"
                                        />
                                        <span class="md-helper-text">Confirm your new Password here</span>
                                    </md-field>
                                </div>

                            </div>

                            <div class="text-right">
                                <md-button class="md-raised md-dense md-primary" type="submit">Change Password</md-button>
                            </div>

                        </div>
                    </md-card-content>

                </md-ripple>
            </md-card>

        </form>
    </div>
</template>

<script>
export default {
    name: 'UpdateProfile',
    data() {
        return {
            user: null,
            form: new Form({
                name: '',
                bio: '',
                email: '',
                phone: '',
                image: '',
                address: '',
            })
        }
    },

    methods: {
        getValidationClass(fieldName) {
            const field = this.form.errors.has(fieldName);
            if (field) {
                return "md-invalid";
            }
        },

        getUser() {
            axios.get("/api/organizations/getUser").then((response) => {
                this.user = response.data.data;
                this.populate()
                // console.log(response.data.data);
            });
        },

        update() {
            this.form.patch('/api/organizations')
                .then(response => {
                    this.$store.dispatch('user/profile');
                    this.$notify({
                        type: (response.data.status) ? 'success' : 'warn',
                        text: response.data.message
                    });
                })
                .catch(e => {
                    if (e.response.status == 422) {
                        this.form.errors.set(e.response.data.error);
                        console.log("422", e.response);
                    }

                    this.$notify({
                        type: 'error',
                        text: e.response.data.message
                    })
                })
                .finally(() => {
                    this.$spinner.hide();
                })
            // console.log('Data', this.form);
        },

        updatePassword() {
            this.form.patch('/api/organizations/change_password')
                .then(response => {
                    this.$store.dispatch('user/profile');
                    this.$notify({
                        type: (response.data.status) ? 'success' : 'warn',
                        text: response.data.message
                    });
                })
                .catch(e => {
                    if (e.response.status == 422) {
                        this.form.errors.set(e.response.data.error);
                        console.log("422", e.response);
                    }

                    this.$notify({
                        type: 'error',
                        text: e.response.data.message
                    })
                })
                .finally(() => {
                    this.$spinner.hide();
                })
            // console.log('Data', this.form);
        },

        handleimage(event) {
            let file = event.target.files[0];
            //console.log(form)
            let reader = new FileReader();
            reader.onload = (event) => {
                this.form.image = event.target.result;
                console.log(event.target.result);
            };
            reader.readAsDataURL(file);
        },

        populate() {
            if (this.user) {
                this.form.name = this.user.details.name;
                this.form.bio = this.user.details.bio;
                this.form.email = this.user.email;
                this.form.phone = this.user.details.phone;
                this.form.image = this.user.details.image;
                this.form.address = this.user.details.address;
            }
        }
    },

    mounted() {
        this.getUser();
    }
}
</script>
