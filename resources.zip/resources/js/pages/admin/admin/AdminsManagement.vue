<template>
    <div>
        <modal name="event-category">
            <div class="mt-3 text-center">
                <h4>
                    {{ edit_mode ? "Edit an Admin" : "Add an Admin" }}
                </h4>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <md-field :class="getValidationClass('name')">
                            <label>Name</label>
                            <md-input v-model="form.name"></md-input>
                            <div
                                v-if="form.errors.has('name')"
                                class="md-error"
                                v-html="form.errors.get('name')"
                            />
                        </md-field>
                    </div>

                    <div class="col-md-6">
                        <md-field :class="getValidationClass('email')">
                            <label>Email</label>
                            <md-input v-model="form.email"></md-input>
                            <div
                                v-if="form.errors.has('email')"
                                class="md-error"
                                v-html="form.errors.get('email')"
                            />
                        </md-field>
                    </div>

                    <div class="col-md-6">
                        <md-field :class="getValidationClass('password')">
                            <label>Password</label>
                            <md-input v-model="form.password" type="password"></md-input>
                            <div
                                v-if="form.errors.has('password')"
                                class="md-error"
                                v-html="form.errors.get('password')"
                            />
                        </md-field>
                    </div>

                    <div class="col-md-6">
                        <md-field :class="getValidationClass('password_confirmation')">
                            <label>Confirm Password</label>
                            <md-input v-model="form.password_confirmation" type="password"></md-input>
                            <div
                                v-if="form.errors.has('password_confirmation')"
                                class="md-error"
                                v-html="form.errors.get('password_confirmation')"
                            />
                        </md-field>
                    </div>

                </div>

                <div class="mt-4">
                    <div class="float-right">
                        <md-button
                            :disabled="form.busy"
                            v-if="edit_mode"
                            @click="updateAdmin"
                            class="md-dense md-raised md-primary"
                        >
                            {{ submitting ? "updating" : "update" }}
                        </md-button>

                        <md-button
                            :disabled="form.busy"
                            v-if="!edit_mode"
                            @click="saveAdmin"
                            class="md-dense md-raised md-primary"
                        >
                            {{ submitting ? "creating" : "create" }}
                        </md-button>
                    </div>
                </div>
            </div>
        </modal>

        <md-table md-card class="round-card md-elevation-5">
            <md-table-toolbar>
                <h1 class="md-title">All Admins</h1>
                <div class="float-right mt-5 mr-2">
                    <md-button
                        class="md-dense md-raised bg-primary text-white"
                        @click="showDialog()"
                    >Create</md-button
                    >
                </div>
            </md-table-toolbar>

            <md-table-row>
                <md-table-head class="text-center">ID</md-table-head>
                <md-table-head class="text-center">Name</md-table-head>
                <md-table-head class="text-center">Email</md-table-head>
                <md-table-head class="text-center">Level</md-table-head>
            </md-table-row>

            <md-table-row
                class="text-center"
                v-for="u in admins"
                :key="u.id"
            >
                <md-table-cell class="text-center" md-numeric>
                    {{ u.id }}
                </md-table-cell>
                <md-table-cell class="text-center">{{ u.name }}</md-table-cell>
                <md-table-cell class="text-center">{{ u.email }}</md-table-cell>
                <md-table-cell class="text-center">{{ u.level }}</md-table-cell>
            </md-table-row>
        </md-table>

        <br />
        <br />

        <div class="float-right">
            <pagination
                :data="pagination"
                @pagination-change-page="loadAdmins"
                page="1"
            ></pagination>
        </div>
    </div>
</template>


<script>
export default {
    data() {
        return {
            admins: {},
            edit_mode: false,
            submitting: false,
            pagination:{},
            form: new Form({
                id: "",
                name: "",
                email: "",
                password: "",
                password_confirmation: "",
            }),
        };
    },

    methods: {
        getValidationClass(fieldName) {
            const field = this.form.errors.has(fieldName);
            if (field) {
                return "md-invalid";
            }
        },

        showDialog() {
            this.$modal.show("event-category");
            this.edit_mode = false;
        },



        saveAdmin() {
            this.$spinner.show();
            this.submitting = true;
            this.form
                .post("/api/admin/storeadmin")
                .then((response) => {
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                    this.form.reset();
                    this.$modal.hide("event-category");
                    this.loadAdmins();
                })
                .catch((e) => {
                    if (e.response.status == 422) {
                        this.form.errors.set(e.response.data.error);
                        console.log("422", e.response);
                    }
                    this.$notify({
                        type: "warn",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                    this.submitting = false;
                });
        },

        loadAdmins(page = 1) {
            this.$spinner.show();
            axios
                .get("/api/admin/all?page=" + page)
                .then((response) => {
                    this.prepPagination(response.data);
                    this.admins = response.data.data;
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        editEventCategory(data) {
            this.edit_mode = true;
            this.form.fill(data);
            this.$modal.show("event-category");
        },

        updateAdmin() {
            this.$spinner.show();
            this.submitting = true;
            this.form
                .put("/api/admin/events/category/update/" + this.form.id)
                .then((response) => {
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                    this.form.reset();
                    this.$modal.hide("event-category");
                    this.loadAdmins();
                })
                .catch((e) => {
                    if (e.response.status == 422) {
                        this.form.errors.set(e.response.data.error);
                    }
                    this.$notify({
                        type: "warn",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                    this.submitting = false;
                });
        },

        confirmDelete(id) {
            this.$confirm({
                message: "Are you sure you want to delete this Admin?",
                button: {
                    no: "No",
                    yes: "Yes",
                },
                callback: (confirm) => {
                    if (confirm) {
                        this.doDelete(id);
                    }
                },
            });
        },

        doDelete(id) {
            this.$spinner.show();
            axios
                .delete("/api/admin/events/category/destroy/" + id)
                .then((response) => {

                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });

                    this.loadEventsCategory();
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },
    },

    mounted() {
        this.loadAdmins();
    },
};
</script>
