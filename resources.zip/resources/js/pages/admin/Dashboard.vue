<template>
    <div>

        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="row">
                    <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                        <h3 class="font-weight-bold">Welcome </h3>
                        <h6 class="font-weight-normal mb-0">
                           <span> You have {{ notifications.length }} unread notifications!</span>
                        </h6>
                    </div>
                    <div class="col-12 col-xl-4 d-none">
                        <div class="justify-content-end d-flex">
                            <div class="dropdown flex-md-grow-1 flex-xl-grow-0">
                                <button class="btn btn-sm btn-light bg-white dropdown-toggle" type="button"
                                        id="dropdownMenuDate2" data-toggle="dropdown" aria-haspopup="true"
                                        aria-expanded="true">
                                    <i class="mdi mdi-calendar"></i> Today (10 Jan 2021)
                                </button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuDate2">
                                    <a class="dropdown-item" href="#">January - March</a>
                                    <a class="dropdown-item" href="#">March - June</a>
                                    <a class="dropdown-item" href="#">June - August</a>
                                    <a class="dropdown-item" href="#">August - November</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-3 mb-4 mb-lg-0 stretch-card transparent">
                <md-card md-with-hover class="card-tale round-card">
                    <md-ripple>
                        <md-card-content>
                            <p class="mb-4">Total Users</p>
                            <p class="fs-30 mb-2">{{ info.users }}</p>
                        </md-card-content>
                    </md-ripple>
                </md-card>
            </div>

            <div class="col-md-3 mb-4 mb-lg-0 stretch-card transparent">
                <md-card md-with-hover class="card-dark-blue round-card">
                    <md-ripple>
                        <md-card-content>
                            <p class="mb-4">Total Individuals</p>
                            <p class="fs-30 mb-2">{{ info.individuals }}</p>
                        </md-card-content>
                    </md-ripple>
                </md-card>
            </div>

            <div class="col-md-3 mb-4 mb-lg-0 stretch-card transparent">
                <md-card md-with-hover class="card-light-blue round-card">
                    <md-ripple>
                        <md-card-content>
                            <p class="mb-4">Total Organizations</p>
                            <p class="fs-30 mb-2">{{ info.organizations }}</p>
                        </md-card-content>
                    </md-ripple>
                </md-card>
            </div>

            <div class="col-md-3 mb-4 mb-lg-0 stretch-card transparent">
                <md-card md-with-hover class="card-light-danger round-card">
                    <md-ripple>
                        <md-card-content>
                            <p class="mb-4">Number of Events</p>
                            <p class="fs-30 mb-2">{{ info.events }}</p>
                        </md-card-content>
                    </md-ripple>
                </md-card>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-6 mb-4">
                <bar-chart :chartData="chartData" :height="200"></bar-chart>
            </div>

            <div class="col-md-6 mb-4">
                <pie-chart :chartData="chartData" :height="200"></pie-chart>
            </div>
        </div>

        <div class="col-lg-12 grid-margin stretch-card px-0">
            <md-card md-with-hover class="round-card">
                <md-ripple>
                    <md-card-header>
                        <div class="row">
                            <div class="col-6">
                                <div class="md-title">Latest Users</div>
                            </div>
                            <!--                            <div class="col-6">-->
                            <!--                                <div class="dropdown float-right">-->
                            <!--                                    <button class="btn btn-primary btn-sm dropdown-toggle" type="button"-->
                            <!--                                            id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"-->
                            <!--                                            aria-expanded="false">-->
                            <!--                                        Export-->
                            <!--                                    </button>-->
                            <!--                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">-->
                            <!--                                        <a class="dropdown-item" :href="'/api/admin/new-customer-export-to-pdf'">PDF</a>-->
                            <!--                                        <a class="dropdown-item" :href="'/api/admin/new-customer-export-to-excel'">Excel</a>-->
                            <!--                                    </div>-->
                            <!--                                </div>-->
                            <!--                            </div>-->
                        </div>
                    </md-card-header>

                    <md-card-content>
                        <div>
                            <md-table>
                                <md-table-row>
                                    <md-table-head md-numeric>ID</md-table-head>
                                    <md-table-head>Name</md-table-head>
                                    <md-table-head>Email</md-table-head>
                                    <md-table-head>Date Created</md-table-head>
<!--                                    <md-table-head>Actions</md-table-head>-->
                                </md-table-row>

                                <md-table-row v-for="(u, index) in users" :key="u.id">
                                    <md-table-cell md-numeric> {{ index + 1 }}</md-table-cell>
                                    <md-table-cell v-if="u.type== 'individual' ">
                                        {{ u.details.firstname + " " + u.details.lastname }}
                                    </md-table-cell>
                                    <md-table-cell v-if="u.type== 'organization' ">{{ u.details.name }}</md-table-cell>
                                    <md-table-cell>{{ u.email }}</md-table-cell>
                                    <md-table-cell> {{ u.details.created_at | moment("from", "now") }}</md-table-cell>
<!--                                    <md-table-cell>-->
<!--                                        <md-button class="md-icon-button md-raised md-accent"-->
<!--                                                   @click="confirmDelete(u.id)">-->
<!--                                            <md-icon>delete</md-icon>-->
<!--                                        </md-button>-->
<!--                                    </md-table-cell>-->
                                </md-table-row>
                            </md-table>
                        </div>
                    </md-card-content>
                    <md-card-actions>
                        <pagination
                            :data="pagination"
                            @pagination-change-page="loadLatestUsers"
                            page="1"
                        ></pagination>
                    </md-card-actions>
                </md-ripple>
            </md-card>
        </div>
    </div>
</template>
<style scoped>
.stretch-card > .round-card {
    width: 100%;
    min-width: 100%;
}

.card-tale {
    background-color: #FC6283 !important;
}

.card-dark-blue {
    background-color: #42BD61 !important;
}

.card-light-blue {
    background-color: #199EF7 !important;
}

.card-light-danger {
    background-color: #FFCD56 !important;
}
</style>
<script>

import BarChart from '../../components/BarChart.js';
import PieChart from '../../components/PieChart.js';

export default {
    components: {
        BarChart,
        PieChart
    },

    data() {
        return {
            users: {},
            info: {},
            status: [{}],
            pagination: {},
            loading: false,
            pending_transactions: [],
            completed_transactions: [],
            cancelled_transactions: [],
            notifications: [],

            chartData: null,
        }
    },

    methods: {

        setupChart(users, organizations, events, individuals) {
            this.chartData = {
                labels: ['Users', 'Organizations', 'Events', 'Individuals'],
                datasets: [
                    {
                        data: [
                            users,
                            organizations,
                            events, individuals
                        ],
                        backgroundColor: [
                            'rgb(255, 99, 132)',
                            'rgb(54, 162, 235)',
                            'rgb(255, 205, 86)',
                            'rgb(44,189,97)',
                        ],
                        hoverOffset: 4
                    }
                ]
            }
        },

        loadDetails() {
            this.$spinner.show();
            axios.get('/api/admin')
                .then(response => {
                    this.populate(response.data.data);
                    this.$notify({
                        type: 'success',
                        text: response.data.message
                    })
                })
                .catch(e => {
                    this.$notify({
                        type: 'error',
                        text: e.message
                    })
                })
                .finally(() => {
                    this.$spinner.hide();
                })
        },

        populate(data) {

            this.setupChart(data.totalUsers, data.totalOrgs, data.totalEvents, data.totalIndividuals);

            this.info = {
                users: data.totalUsers,
                events: data.totalEvents,
                organizations: data.totalOrgs,
                individuals: data.totalIndividuals
            }
        },

        confirmDelete(id) {

            this.$confirm({
                message: 'Are you sure you want to delete this User?',
                button: {
                    no: 'No',
                    yes: 'Yes'
                },
                callback: (confirm) => {
                    if (confirm) {
                        this.doDelete(id);
                    }
                }
            })
        },

        doDelete(id) {
            this.$spinner.show();
            axios.delete('/api/admin/users/' + id)
                .then(response => {
                    this.loadLatestUsers();
                    this.$notify({
                        type: 'success',
                        text: response.data.message
                    });
                })
                .catch(e => {
                    this.$notify({
                        type: 'error',
                        text: e.message
                    })
                })
                .finally(() => {
                    this.$spinner.hide();
                })
        },

        loadLatestUsers(page = 1) {
            this.$spinner.show();
            axios
                .get("/api/admin/allLatestusers?page=" + page)
                .then((response) => {
                    this.prepPagination(response.data);
                    this.users = response.data.data;
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

    },

    mounted() {
        this.loadDetails();
        this.loadLatestUsers();
    }
}
</script>
