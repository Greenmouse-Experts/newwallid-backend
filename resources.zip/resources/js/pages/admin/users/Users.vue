<template>
    <div>
        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="row">
                        <div class="col-6">
                            <div class="md-title text-capitalize">{{ $route.params.status ? $route.params.status : type }} Users</div>
                        </div>
                    </div>
                </md-card-header>

                <md-card-content>
                    <div>
                        <md-table>
                            <md-table-row>
                                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                <md-table-head class="text-center">Name</md-table-head>
                                <md-table-head class="text-center">Email</md-table-head>
                                <md-table-head class="text-center">Date Created</md-table-head>
                                <md-table-head class="text-center"> Status</md-table-head>
                                <md-table-head class="text-center">Actions</md-table-head>
                            </md-table-row>

                            <md-table-row v-for="(u, index) in users" :key="u.id">
                                <md-table-cell class="text-center" md-numeric> {{ u.id }}</md-table-cell>
                                <md-table-cell class="text-center" v-if="u.type== 'individual' ">
                                    {{ u.details.firstname + " " + u.details.lastname }}
                                </md-table-cell>
                                <md-table-cell class="text-center" v-if="u.type== 'organization' ">{{
                                        u.details.name
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">{{ u.email }}</md-table-cell>

                                <md-table-cell class="text-center"> {{
                                        u.details.created_at | moment("from", "now")
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <md-chip v-if="u.status == 'active' " class="bg-success">
                                        {{ u.status }}
                                    </md-chip>
                                    <md-chip v-if="u.status != 'active' " class="md-accent">
                                        {{ u.status }}
                                    </md-chip>
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <md-button v-if="u.status == 'active'"
                                               class="md-raised md-dense md-accent rounded"
                                               @click="confirmAction('Suspend', u.id)">
                                        Suspend
                                    </md-button>

                                    <md-button v-if="u.status == 'suspended'"
                                               class="md-raised md-dense bg-success rounded"
                                               @click="confirmAction('Activate', u.id)">
                                        Activate
                                    </md-button>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>
                <md-card-actions>
                    <pagination
                        :data="pagination"
                        @pagination-change-page="loadUsers"
                        page="1"
                    ></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>

<script>
export default {
    name: "Users",
    data() {
        return {
            type: "All",
            users: [],
            pagination: {},

            status: null,
            baseUrl: "/api/admin/users",
        };
    },

    watch: {
        $route(to, from) {
            if (to.params.status) {
                this.status = to.params.status;
                this.loadUsers();
            }

            this.loadUsers();
        },
    },

    methods: {
        loadUsers(page = 1) {

            let url = this.status ? this.baseUrl + "/" + this.status : this.baseUrl;

            this.$spinner.show();
            axios
                .get(url + "?page=" + page)
                .then((response) => {
                    this.users = response.data.data;
                    this.status = undefined;
                    this.prepPagination(response.data);
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        prepPagination(data) {
            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total,
            };
        },

        confirmAction(status, id) {
            this.$confirm({
                message: `Are you sure you want to ${status} this User?`,
                button: {
                    no: "No",
                    yes: "Yes",
                },
                callback: (confirm) => {
                    if (confirm) {
                        let st = status == "Activate" ? "active" : "suspended";
                        this.doAction(id, st);
                    }
                },
            });
        },

        doAction(id, status) {
            this.$spinner.show();
            axios
                .get("/api/admin/users/" + id + "/" + status)
                .then((response) => {
                    console.log(response);

                    for (var i = 0; i < this.users.length; i++) {
                        if (this.users[i].id == id) {
                            this.users[i] = response.data.data;
                        }
                    }
                    this.loadUsers();
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },
    },

    mounted() {

        this.status = this.$route.params.status;
        this.loadUsers();
    },
};
</script>
