<template>
	<div>

        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="row">
                        <div class="col-6">
                            <div v-if="$route.params.status" class="md-title text-capitalize">{{ ($route.params.status == 1) ? "Activated" : "Suspended"}} Organizations</div>
                            <div v-if="!$route.params.status" class="md-title text-capitalize">{{ type }} Organizations</div>
                        </div>
                    </div>
                </md-card-header>

                <md-card-content>
                    <div>
                        <md-table>
                            <md-table-row>
                                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                <md-table-head class="text-center">Name</md-table-head>
                                <md-table-head class="text-center">Date Created</md-table-head>
                                <md-table-head class="text-center"> Status</md-table-head>
                                <md-table-head class="text-center">Actions</md-table-head>
                            </md-table-row>

                            <md-table-row v-for="(row, index) in organizations" :key="row.id">
                                <md-table-cell class="text-center" md-numeric> {{ row.id }}</md-table-cell>
                                <md-table-cell class="text-center">{{
                                        row.name
                                    }}
                                </md-table-cell>

                                <md-table-cell class="text-center"> {{
                                        row.created_at | moment("from", "now")
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <md-chip v-if="row.status == 1 " class="bg-success">
                                        Active
                                    </md-chip>
                                    <md-chip v-if="row.status == 0 " class="md-accent">
                                        Suspended
                                    </md-chip>
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    <md-button v-if="row.status == 1 "
                                               class="md-raised md-dense md-accent rounded"
                                               @click="confirmAction('Suspend', row.id)">
                                        Suspend
                                    </md-button>

                                    <md-button v-if="row.status == 0 "
                                               class="md-raised md-dense bg-success rounded"
                                               @click="confirmAction('Activate', row.id)">
                                        Activate
                                    </md-button>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>
                <md-card-actions>
                    <pagination
                        :data="pagination"
                        @pagination-change-page="loadOrganizations"
                        page="1"
                    ></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				type: 'All',
				organizations: [],
				pagination: {},

				status: null,
				baseUrl: '/api/admin/organizations'
			}
		},

		watch:{
	   	 	$route (to, from) {
		    	if (to.params.status != this.status) {
		    		this.status = to.params.status;
		    		this.loadOrganizations();
		    	}
		    }
		},

		methods: {

			loadOrganizations(page = 1) {

				let url = (this.status) ? this.baseUrl + '/' + this.status : this.baseUrl;
				this.$spinner.show();
				axios.get(url + '?page=' + page)
					.then(response => {
						this.organizations = response.data.data;
						this.prepPagination(response.data);

					})
					.catch(e => {
						this.$notify({
							type: 'error',
							text: e.message
						});
					})
					.finally(() => {
						this.$spinner.hide();
					})
			},

			prepPagination(data) {

				this.pagination = {
					data: data.data,
					current_page: data.meta.current_page,
					first_item: data.meta.first_item,
					last_item: data.meta.last_item,
					last_page: data.meta.last_page,
					next_page_url: data.meta.next_page_url,
					per_page: data.meta.per_page,
					previous_page_url: data.meta.previous_page_url,
					total: data.meta.total
				}
			},

	      	confirmAction(status, id) {

				this.$confirm({
					message: `Are you sure you want to ${status} this Organization?`,
					button: {
						no: 'No',
						yes: 'Yes'
					},
					callback: (confirm) => {
						if(confirm) {
							let st = (status == 'Activate') ? 1 : 0;
							this.doAction(id, st);
						}
					}
				})
			},

			doAction(id, status) {
				this.$spinner.show();
				axios.get('/api/admin/organizations/' + id + '/' + status)
		    		.then(response => {
		    			for (var i = 0; i < this.organizations.length; i++) {
		    				if (this.organizations[i].id == id) {
		    					this.organizations[i] = response.data.data;
		    				}
		    			}
                        this.loadOrganizations();
		    			this.$notify({
		    				type: 'success',
		    				text: response.data.message
		    			});
		    		})
		    		.catch(e => {
		    			this.$notify({
		    				type: 'error',
		    				text: e.message
		    			})
		    		})
		    		.finally(() => {
		    			this.$spinner.hide();
		    		})
			}
		},

		mounted() {
			this.status = this.$route.params.status;
			this.loadOrganizations();
		}
	}
</script>
