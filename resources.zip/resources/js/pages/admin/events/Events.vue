<template>
    <div>

        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="row">
                        <div class="col-6">
                            <div class="md-title text-capitalize"> All Events</div>
                        </div>
                    </div>
                </md-card-header>

                <md-card-content>
                    <div>
                        <md-table>
                            <md-table-row>
                                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                <md-table-head class="text-center">Name</md-table-head>
                                <md-table-head class="text-center">Creator Name</md-table-head>
                                <md-table-head class="text-center"> Creator Email</md-table-head>
                                <md-table-head class="text-center"> Free</md-table-head>
                                <md-table-head class="text-center"> Tickets</md-table-head>
                                <md-table-head class="text-center">Status</md-table-head>
                                <md-table-head class="text-center">Actions</md-table-head>
                            </md-table-row>

                            <md-table-row v-for="(row, index) in events" :key="row.id">
                                <md-table-cell class="text-center" md-numeric> {{ row.id }}</md-table-cell>

                                <md-table-cell class="text-center">{{
                                        row.name
                                    }}
                                </md-table-cell>

                                <md-table-cell  v-if="row.user.type == 'organization' " class="text-center">{{
                                        row.user.details.name
                                    }}
                                </md-table-cell>

                                <md-table-cell v-if="row.user.type == 'individual' " class="text-center">
                                    {{ row.user.details.firstname }} {{ row.user.details.lastname }}
                                </md-table-cell>

                                <md-table-cell class="text-center">
                                    {{ row.user.email }}
                                </md-table-cell>

                                <md-table-cell class="text-center">
                                    {{ row.isFree }}
                                </md-table-cell>

                                <md-table-cell class="text-center">
                                    {{ row.tickets }}
                                </md-table-cell>

                                <md-table-cell class="text-center">
                                    <md-chip :class="getStatus(row.status)">
                                        {{ row.status }}
                                    </md-chip>

                                </md-table-cell>


                                <md-table-cell class="text-center">
                                    <md-button
                                        class="md-fab md-mini bg-view"
                                        :to="$route.path + '/' + row.id"
                                    >
                                        <md-icon>article</md-icon>
                                        <md-tooltip md-direction="bottom">View Event</md-tooltip>
                                    </md-button>
                                </md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>
                <md-card-actions>
                    <pagination :data="pagination" @pagination-change-page="loadEvents" page="1"></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>
    </div>
</template>


<script>
export default {
    data() {
        return {

            events: [],
            pagination: {},
            baseUrl: '/api/admin/events'
        }
    },

    methods: {
        getStatus(data){
            if (data == 'open'){
                return "bg-success"
            }
            if (data == 'closed'){
                return "md-accent"
            }
            if (data == 'suspended'){
                return "bg-warning"
            }
            if (data == 'ongoing'){
                return "md-primary"
            }
        },

        loadEvents(page = 1) {

            this.$spinner.show();
            axios.get(this.baseUrl + '?page=' + page)
                .then(response => {
                    console.log(response);
                    this.events = response.data.data;
                    this.prepPagination(response.data);
                })
                .catch(e => {
                    this.$notify({
                        type: 'error',
                        text: e.message
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                })
        },

        prepPagination(data) {

            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total
            }
        }
    },

    mounted() {
        this.loadEvents();
    }
}
</script>
