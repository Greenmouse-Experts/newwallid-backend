<template>
  <div>
    <modal name="event-category">
      <div class="mt-3 text-center">
        <h4>
          {{ edit_mode ? "Edit Event Category" : "Add Event Category" }}
        </h4>
      </div>

      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <md-field>
              <label>Name</label>
              <md-input v-model="form.name"></md-input>
            </md-field>
          </div>

          <div class="col-md-6">
            <md-field>
              <label>Description</label>
              <md-textarea v-model="form.description" md-autogrow></md-textarea>
            </md-field>
          </div>
        </div>

        <div class="mt-4">
          <div class="float-right">
            <md-button
              :disabled="form.busy"
              v-if="edit_mode"
              @click="updateEventCategory"
              class="md-dense md-raised md-primary"
            >
              {{ submitting ? "updating" : "update" }}
            </md-button>

            <md-button
              :disabled="form.busy"
              v-if="!edit_mode"
              @click="saveEventCategory"
              class="md-dense md-raised md-primary"
            >
              {{ submitting ? "creating" : "create" }}
            </md-button>
          </div>
        </div>
      </div>
    </modal>

    <md-table md-card class="round-card">
      <md-table-toolbar>
        <h1 class="md-title">Events Category</h1>
        <div class="float-right mt-5 mr-2">
          <md-button
            class="md-dense md-raised bg-primary text-white"
            @click="showDialog()"
            >Create</md-button
          >
        </div>
      </md-table-toolbar>

      <md-table-row>
        <md-table-head class="text-center">ID</md-table-head>
        <md-table-head class="text-center">Name</md-table-head>
        <md-table-head class="text-center">Description</md-table-head>
        <md-table-head class="text-center">Actions</md-table-head>
      </md-table-row>

      <md-table-row
        class="text-center"
        v-for="category in categories.data"
        :key="category.id"
      >
        <md-table-cell class="text-center" md-numeric>
          {{ category.id }}
        </md-table-cell>
        <md-table-cell class="text-center">{{ category.name }}</md-table-cell>
        <md-table-cell class="text-center">{{
          category.description
        }}</md-table-cell>
        <md-table-cell class="text-center">
          <div class="btn-group" role="group" aria-label="Basic example">
            <md-button
              class="md-fab md-mini bg-edit"
              @click="editEventCategory(category)"
            >
              <md-icon>edit</md-icon>
              <md-tooltip md-direction="bottom">Edit Event</md-tooltip>
            </md-button>

            <md-button
              class="md-fab md-mini"
              @click="confirmDelete(category.id)"
            >
              <md-icon>delete</md-icon>
              <md-tooltip md-direction="bottom">Delete Event</md-tooltip>
            </md-button>
          </div>
        </md-table-cell>
      </md-table-row>
    </md-table>

    <br />
    <br />

    <div class="float-right">
      <pagination
        :data="categories"
        @pagination-change-page="getResults"
      ></pagination>
    </div>
  </div>
</template>


<script>
export default {
  data() {
    return {
      categories: {},
      edit_mode: false,
      submitting: false,
      form: new Form({
        id: "",
        name: "",
        description: "",
      }),
    };
  },

  methods: {
    showDialog() {
      this.$modal.show("event-category");
      this.edit_mode = false;
    },

    saveEventCategory() {
      this.$spinner.show();
      this.submitting = true;
      this.form
        .post("/api/admin/events/category/store")
        .then((response) => {
          this.$notify({
            type: "success",
            text: response.data.message,
          });
          this.form.reset();
          this.$modal.hide("event-category");
          this.loadEventsCategory();
        })
        .catch((e) => {
          console.log("Error", e);
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
          this.submitting = false;
        });
    },

    loadEventsCategory() {
      this.$spinner.show();
      axios
        .get("/api/admin/events/category/all")
        .then((response) => {
          // console.log(response);
          this.categories = response.data.data;
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },
    getResults(page = 1) {
      axios
        .get("/api/admin/events/category/all?page=" + page)
        .then((response) => {
          this.categories = response.data.data;
        });
    },

    editEventCategory(data) {
      this.edit_mode = true;
      this.form.fill(data);
      this.$modal.show("event-category");
    },

    updateEventCategory() {
      this.$spinner.show();
      this.submitting = true;
      this.form
        .put("/api/admin/events/category/update/" + this.form.id)
        .then((response) => {
          this.$notify({
            type: "success",
            text: response.data.message,
          });
          this.form.reset();
          this.$modal.hide("event-category");
          this.loadEventsCategory();
        })
        .catch((e) => {
          console.log("Error", e);
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
          this.submitting = false;
        });
    },

    confirmDelete(id) {
      this.$confirm({
        message: "Are you sure you want to delete this Category?",
        button: {
          no: "No",
          yes: "Yes",
        },
        callback: (confirm) => {
          if (confirm) {
            this.doDelete(id);
          }
        },
      });
    },

    doDelete(id) {
      this.$spinner.show();
      axios
        .delete("/api/admin/events/category/destroy/" + id)
        .then((response) => {

          this.$notify({
            type: "success",
            text: response.data.message,
          });

           this.loadEventsCategory();
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },
  },

  mounted() {
    this.loadEventsCategory();
  },
};
</script>
