<template>
    <div>

        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="row">
                        <div class="col-6">

                            <div class="md-title text-capitalize"> All Subscription Payments</div>
                        </div>
                    </div>
                </md-card-header>

                <md-card-content>
                    <div>
                        <md-table>
                            <md-table-row>
                                <md-table-head class="text-center" md-numeric> Subscription ID</md-table-head>
                                <md-table-head class="text-center">Payee Name</md-table-head>
                                <md-table-head class="text-center">Subscription Plan ID</md-table-head>
                                <md-table-head class="text-center">Organization Name</md-table-head>
                                <md-table-head class="text-center">Amount</md-table-head>
                                <md-table-head class="text-center"> Reference</md-table-head>
                                <md-table-head class="text-center">fees</md-table-head>
                                <md-table-head class="text-center">Channel</md-table-head>
                                <md-table-head class="text-center">IP Address</md-table-head>
                            </md-table-row>

                            <md-table-row v-for="(row, index) in payments" :key="row.id">
                                <md-table-cell class="text-center" md-numeric> {{ row.id }}</md-table-cell>
                                <md-table-cell class="text-center">
                                    {{ row.individual.firstname + " " + row.individual.lastname }}
                                </md-table-cell>
                                <md-table-cell class="text-center" v-if="row.user.type == 'individual' ">
                                    {{ row.subscription_plan.id }}
                                </md-table-cell>
                                <md-table-cell class="text-center">
                                    {{ row.organization.name }}
                                </md-table-cell>
                                <md-table-cell class="text-center"> {{
                                        row.payment.amount | formatCurrency
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center"> {{ row.payment.reference }}</md-table-cell>
                                <md-table-cell class="text-center"> {{
                                        row.payment.fees | formatCurrency
                                    }}
                                </md-table-cell>
                                <md-table-cell class="text-center"> {{ row.payment.channel }}</md-table-cell>
                                <md-table-cell class="text-center"> {{ row.payment.ip_address }}</md-table-cell>
                            </md-table-row>
                        </md-table>
                    </div>
                </md-card-content>
                <md-card-actions>
                    <pagination
                        :data="pagination"
                        @pagination-change-page="loadPayments"
                        page="1"
                    ></pagination>
                </md-card-actions>
            </md-ripple>
        </md-card>

    </div>
</template>


<script>
export default {
    data() {
        return {

            payments: {},
            pagination: {},
            baseUrl: '/api/admin/payments/subscriptions'
        }
    },

    methods: {

        loadPayments(page = 1) {

            this.$spinner.show();
            axios.get(this.baseUrl + '?page=' + page)
                .then(response => {
                    // console.log(response);
                    this.payments = response.data.data;
                    this.prepPagination(response.data);
                })
                .catch(e => {
                    this.$notify({
                        type: 'error',
                        text: e.response.data.message
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                })
        },

        prepPagination(data) {

            this.pagination = {
                data: data.data,
                current_page: data.meta.current_page,
                first_item: data.meta.first_item,
                last_item: data.meta.last_item,
                last_page: data.meta.last_page,
                next_page_url: data.meta.next_page_url,
                per_page: data.meta.per_page,
                previous_page_url: data.meta.previous_page_url,
                total: data.meta.total
            }
        }
    },

    mounted() {
        this.loadPayments();
    }
}
</script>
