<template>
	<div>
		<div class="row py-5">
			<div class="col-md-6 mx-auto">
				<div class="card">
			<div class="card-body">
				<p class="card-title">Event Ticket Purchased</p>
				<div class="mb-4">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</div>

				<a href="/home" class="btn btn-danger">Dashboard</a>
			</div>
		</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: '',
		data() {
			return {

			}
		},

		mounted() {
		
		}
	}
</script>