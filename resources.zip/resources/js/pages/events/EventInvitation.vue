<template>
  <div>
    <md-card md-with-hover class="round-card mb-4">
      <md-ripple>
        <md-card-header>
          <div class="md-title text-dark"><b> Send Invitation </b></div>
          <!-- <div class="md-subhead">It also have a ripple</div> -->
        </md-card-header>

        <md-card-content>
          <form
            class=""
            @submit.prevent="sendInvite"
            @keydown="form.onKeydown($event)"
          >
            <div class="row mb-4">
              <div class="col-md-6">
                <md-field :class="getValidationClass('event_id')">
                  <label>Event ID</label>
                  <md-input v-model="form.event_id"></md-input>
                  <div
                    v-if="form.errors.has('event_id')"
                    class="md-error"
                    v-html="form.errors.get('event_id')"
                  />
                </md-field>
              </div>

              <div class="col-md-6">
                <md-field :class="getValidationClass('username')">
                  <label>Receiver Username</label>
                  <md-input v-model="form.username"></md-input>
                  <div
                    v-if="form.errors.has('username')"
                    class="md-error"
                    v-html="form.errors.get('username')"
                  />
                </md-field>
              </div>
            </div>
            <div class="text-right">
              <md-button
                type="submit"
                class="md-dense md-raised bg-primary round-card text-white"
                >Send</md-button
              >
            </div>
          </form>
        </md-card-content>
      </md-ripple>
    </md-card>

    <md-card md-with-hover class="round-card">
      <md-ripple>
        <md-card-header>
          <div class="md-title text-dark">
            <b> {{ filter }} Invitations</b>
          </div>
          <!-- <div class="md-subhead">It also have a ripple</div> -->
          <div class="float-right mr-5">
            <md-menu md-direction="bottom-start" md-size="auto">
              <md-button md-menu-trigger class="md-fab md-mini bg-share">
                <md-icon>filter_alt</md-icon>
              </md-button>

              <md-menu-content>
                <md-menu-item>
                  <md-button class="" @click="getallRequests">
                    All My Invites
                  </md-button>
                </md-menu-item>

                <md-menu-item>
                  <md-button class="" @click="getUpcomingRequests">
                    Upcoming Event Invites
                  </md-button>
                </md-menu-item>

                <md-menu-item>
                  <md-button class="" @click="getAcceptedRequests">
                    Accepted Event Invites
                  </md-button>
                </md-menu-item>

                <md-menu-item>
                  <md-button class="" @click="getDeclinedRequests">
                    Declined Event Invites
                  </md-button>
                </md-menu-item>

                <md-menu-item>
                  <md-button class="" @click="getCheckedInRequests">
                    Checked In Event Invites
                  </md-button>
                </md-menu-item>

                <md-menu-item>
                  <md-button class="" @click="getPastRequests">
                    Past Events Invites
                  </md-button>
                </md-menu-item>
              </md-menu-content>
            </md-menu>
          </div>
        </md-card-header>

        <md-card-content>
          <div class="mt-4">
            <md-table>
              <md-table-row>
                <md-table-head class="text-center" md-numeric>#</md-table-head>
                <md-table-head class="text-center">Title</md-table-head>
                <md-table-head class="text-center">Invited By</md-table-head>
                <md-table-head class="text-center"
                  >Event Start Date</md-table-head
                >
                <md-table-head class="text-center">Is Free</md-table-head>
                <md-table-head class="text-center">Invited On</md-table-head>
                <md-table-head class="text-center">Status</md-table-head>
                <md-table-head class="text-center">Action</md-table-head>
              </md-table-row>

              <md-table-row v-for="(row, index) in invitations" :key="row.id">
                <md-table-cell class="text-center" md-numeric>
                  {{ row.id }}
                </md-table-cell>
                <md-table-cell class="text-center">{{
                  row.event.name
                }}</md-table-cell>
                <md-table-cell class="text-center">{{
                  row.sender
                }}</md-table-cell>
                <md-table-cell class="text-center">{{
                  row.event.start_date | moment("dddd, Do MMMM YYYY")
                }}</md-table-cell>
                <md-table-cell class="text-center">{{
                  row.event.isFree == "true" ? "Yes" : "No"
                }}</md-table-cell>
                <md-table-cell class="text-center">{{
                  row.sent_on | moment("dddd, Do MMMM YYYY")
                }}</md-table-cell>

                <md-table-cell class="text-center">
                  <md-chip class="md-primary" v-if="row.status == 'pending'"
                    >Pending</md-chip
                  >
                  <md-chip class="bg-success" v-if="row.status == 'approved'"
                    >Accepted</md-chip
                  >
                  <md-chip class="md-accent" v-if="row.status == 'declined'"
                    >Declined</md-chip
                  >
                </md-table-cell>

                <md-table-cell class="text-center">
                  <md-button
                    class="md-dense md-raised md-accent round-card"
                    @click="decline(row.id)"
                    v-if="row.status == 'pending'"
                  >
                    <md-tooltip md-direction="bottom">Decline Event</md-tooltip>
                    Decline
                  </md-button>

                  <md-button
                    :to="row.event.id + '/info'"
                    class="md-dense md-raised bg-view round-card text-white"
                  >
                    <md-tooltip md-direction="bottom"
                      >View Event Details</md-tooltip
                    >
                    View Details
                  </md-button>
                </md-table-cell>
              </md-table-row>
            </md-table>
          </div>
        </md-card-content>

        <md-card-actions>
          <pagination
            :data="pagination"
            @pagination-change-page="getRequests"
          ></pagination>
        </md-card-actions>
      </md-ripple>
    </md-card>
  </div>
</template>

<script>
export default {
  name: "EventInvitation",
  data() {
    return {
      invitations: [],
      filter: "All My",
      pagination: {},
      api_path: "/api/events/invites",

      form: new Form({
        event_id: "",
        username: "",
      }),
    };
  },
  computed: {
    url: () => {
      return "event-info";
    },
  },
  methods: {
    getValidationClass(fieldName) {
      const field = this.form.errors.has(fieldName);
      if (field) {
        return "md-invalid";
      }
    },

    getRequests(page = 1) {
      this.$spinner.show();
      axios
        .get(this.api_path + "?page=" + page)
        .then((response) => {
          this.prepPagination(response.data);
          this.invitations = response.data.data;
          this.$notify({
            type: "success",
            text: response.data.message,
          });
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },

    prepPagination(data) {
      this.pagination = {
        data: data.data,
        current_page: data.meta.current_page,
        first_item: data.meta.first_item,
        last_item: data.meta.last_item,
        last_page: data.meta.last_page,
        next_page_url: data.meta.next_page_url,
        per_page: data.meta.per_page,
        previous_page_url: data.meta.previous_page_url,
        total: data.meta.total,
      };
    },

    getallRequests() {
      this.api_path = "/api/events/invites";
      this.getRequests();
      this.filter = "All My";
    },

    getUpcomingRequests() {
      this.api_path = "/api/events/invites/upcoming";
      this.getRequests();
      this.filter = "Upcoming";
    },

    getPastRequests() {
      this.api_path = "/api/events/invites/past";
      this.getRequests();
      this.filter = "Past";
    },

    getAcceptedRequests() {
      this.api_path = "/api/events/invites/accepted";
      this.getRequests();
      this.filter = "Accepted";
    },

    getDeclinedRequests() {
      this.api_path = "/api/events/invites/declined";
      this.getRequests();
      this.filter = "Declined";
    },

    getCheckedInRequests() {
      this.api_path = "/api/events/invites/checked_in";
      this.getRequests();
      this.filter = "Checked In";
    },

    sendInvite() {
      this.$spinner.show();
      this.form
        .post("/api/events/invite")
        .then((response) => {
          this.$notify({
            type: response.data.status ? "success" : "warn",
            text: response.data.message,
          });
          this.getRequests();
          if (response.data.status) {
            this.form.reset();
          }
        })
        .catch((e) => {
          if (e.response.status == 422) {
            this.form.errors.set(e.response.data.error);
            console.log("422", e.response);
          }
          this.$notify({
            type: "error",
            text: e.response.data.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },

    decline(id) {
      this.$confirm({
        message: "Decline Invitation?",
        button: {
          no: "No",
          yes: "Yes",
        },
        callback: (confirm) => {
          if (confirm) {
            this.doDeline(id);
          }
        },
      });
    },

    doDeline(id) {
      this.$spinner.show();
      axios
        .get("/api/events/requests/" + id + "/declined")
        .then((response) => {
          this.$notify({
            type: "success",
            text: response.data.message,
          });
          this.getRequests();
          this.$notify({
            type: "success",
            text: "Event Invite Declined Successfully",
          });
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },
  },
  mounted() {
    this.getRequests();
  },
};
</script>
