<template>
    <div>
        <modal
            name="attendeeDetails"
            :adaptive="true"
            :scrollable="true"
            height="auto"
            width="80%"
            @before-close="clearModalData"
        >

            <div>
                <md-card md-with-hover class="round-card ml-3 mr-3 mt-3 mb-3">
                    <md-ripple>
                        <md-card-header>
                            <div class="md-title">More Details about Attendee</div>
                        </md-card-header>

                        <md-card-content>
                            <div class="mt-4">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="md-subhead text-center">Payment Details</div>

                                        <div class="mt-3">
                                            <p>
                                                <b>ID :</b> {{ attendee_payment.id }}
                                            </p>

                                            <p>
                                                <b>Ticket ID Paid for :</b> {{ attendee_payment.ticket_id }}
                                            </p>

                                            <p>
                                                <b>Amount Paid :</b> {{ attendee_payment.amount | formatCurrency }}
                                            </p>

                                            <p>
                                                <b>Channel of Payment :</b> {{ attendee_payment.channel }}
                                            </p>

                                            <p>
                                                <b>Paid At :</b>
                                                {{ attendee_payment.paid_at | moment("dddd, Do MMMM YYYY") }}
                                            </p>

                                            <p>
                                                <b>Payment Reference :</b> {{ attendee_payment.reference }}
                                            </p>

                                            <p>
                                                <b>Payment Status :</b>
                                                <md-chip class="bg-success"> {{ attendee_payment.status }}</md-chip>
                                            </p>


                                        </div>

                                    </div>
                                    <div class="col-md-6">
                                        <div class="md-subhead text-center">Ticket Category Details</div>
                                        <div class="mt-3">
                                            <h4 class="text-center" v-if="!attendee_ticketcategory"> This event has no
                                                ticket Category</h4>
                                            <div v-if="attendee_ticketcategory">
                                                <p>
                                                    <b>ID :</b> {{ attendee_ticketcategory.id }}
                                                </p>
                                                <p>
                                                    <b>Name :</b> {{ attendee_ticketcategory.name}}
                                                </p>
                                                <p>
                                                    <b>Price :</b> {{attendee_ticketcategory.price | formatCurrency }}
                                                </p>
                                                <p>
                                                    <b>Description :</b> {{ attendee_ticketcategory.description }}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </md-card-content>
                    </md-ripple>
                </md-card>
            </div>
        </modal>
        <div class="row">
            <div class="col-md-4">
                <md-card md-with-hover class="round-card">
                    <md-ripple>
                        <md-card-header>
                            <div class="md-title">Event Details</div>
                            <!--                    <div class="md-subhead">It also have a ripple</div>-->
                        </md-card-header>

                        <md-card-content>
                            <div>
                                <p>
                                    <b>ID: </b> {{ event.event.unique_id }}
                                </p>

                                <p>
                                    <b>Name: </b> {{ event.event.name }}
                                </p>

                                <p>
                                    <b>Description: </b> {{ event.event.description }}
                                </p>

                                <p>
                                    <b>isFree: </b> {{ event.event.isFree }}
                                </p>

                                <p v-if="event.event.pricing == 'single' ">
                                    <b>Price: </b> {{ event.event.price | formatCurrency }}
                                </p>

                                <p>
                                    <b>Pricing: </b> {{ event.event.pricing }}
                                </p>

                                <md-card-expand v-if="event.event.pricing != 'single' ">
                                    <md-card-actions md-alignment="space-between">
                                        <b>Ticket Categories: </b>
                                        <md-card-expand-trigger>
                                            <md-button class="md-icon-button">
                                                <md-icon>keyboard_arrow_down</md-icon>
                                            </md-button>
                                        </md-card-expand-trigger>
                                    </md-card-actions>

                                    <md-card-expand-content>
                                        <md-card-content>
                                            <div>
                                                <md-table>
                                                    <md-table-row>
                                                        <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                                        <md-table-head class="text-center">Name</md-table-head>
                                                        <md-table-head class="text-center">Price</md-table-head>
                                                    </md-table-row>

                                                    <md-table-row v-for="category in event.event.ticketCategories"
                                                                  :key="category.id">
                                                        <md-table-cell class="text-center" md-numeric>
                                                            {{ category.id }}
                                                        </md-table-cell>
                                                        <md-table-cell class="text-center">{{
                                                                category.name
                                                            }}
                                                        </md-table-cell>
                                                        <md-table-cell class="text-center">
                                                            {{ category.price | formatCurrency }}
                                                        </md-table-cell>
                                                    </md-table-row>
                                                </md-table>
                                            </div>
                                        </md-card-content>
                                    </md-card-expand-content>
                                </md-card-expand>

                                <p>
                                    <b>Start Date: </b> {{ event.event.start_date | moment("dddd, Do MMMM YYYY") }}
                                </p>

                                <p>
                                    <b>End Date: </b> {{ event.event.end_date | moment("dddd, Do MMMM YYYY") }}
                                </p>

                                <p>
                                    <b>Start Time: </b> {{ event.event.start_time }}
                                </p>

                                <p>
                                    <b>End Time: </b> {{ event.event.end_time }}
                                </p>

                                <p>
                                    <b>Venue </b> {{ event.event.venue }}
                                </p>

                                <p>
                                    <b>Type: </b> {{ event.event.type }}
                                </p>

                                <p>
                                    <b>Tickets: </b> {{ event.event.tickets }}
                                </p>

                                <p>
                                    <b>Available Tickets: </b> {{ event.event.tickets - event.purchased_tickets }}
                                </p>

                                <p>
                                    <b>Created On: </b> {{ event.event.created_at | moment("dddd, Do MMMM YYYY") }}
                                </p>
                            </div>
                        </md-card-content>

                    </md-ripple>
                </md-card>
            </div>

            <div class="col-md-8">
                <md-card md-with-hover class="round-card">
                    <md-ripple>
                        <md-card-header>
                            <div class="md-title">Event Images</div>
                        </md-card-header>

                        <md-card-content>
                            <div>
                                <div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <md-card md-with-hover class="round-card">
                                                <md-card-media-cover md-solid>
                                                    <md-card-media>
                                                        <img class="perfectEventImages"
                                                             :src="getImage(event.event.image)"
                                                             alt="Event Image">
                                                    </md-card-media>

                                                    <md-card-area>
                                                        <md-card-header>
                                                            <span class="md-subhead">Event Image</span>
                                                        </md-card-header>
                                                    </md-card-area>
                                                </md-card-media-cover>
                                            </md-card>
                                        </div>
                                        <div class="col-md-6">
                                            <md-card md-with-hover class="round-card">
                                                <md-card-media-cover md-solid>
                                                    <md-card-media>
                                                        <img class="perfectEventImages"
                                                             :src="getVenueImage(event.event.venue_image)"
                                                             alt="Venue Image">
                                                    </md-card-media>

                                                    <md-card-area>
                                                        <md-card-header>
                                                            <span class="md-subhead">Event Venue Image</span>
                                                        </md-card-header>
                                                    </md-card-area>
                                                </md-card-media-cover>
                                            </md-card>
                                        </div>
                                    </div>

                                    <div class="mt-4">
                                        <div class="col-md-12">
                                            <span class="md-title">{{
                                                    showCreatedByDetails ? "Created By" : "Event Category Details"
                                                }}</span>

                                            <span class="float-right">
                                        <md-button class="md-raised md-dense md-primary"
                                                   @click="toogleShowButton(showCreatedByDetails)">
                                         {{
                                                showCreatedByDetails ? "Event Category Details" : "Show Event Creator Details"
                                            }}
                                        </md-button>
                                    </span>
                                        </div>

                                    </div>

                                    <div class="mt-4">
                                        <md-table v-if="showCreatedByDetails">
                                            <md-table-row>
                                                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                                <md-table-head class="text-center">Full Name</md-table-head>
                                                <md-table-head class="text-center">Email</md-table-head>
                                                <md-table-head class="text-center">Username</md-table-head>
                                                <md-table-head class="text-center">Phone</md-table-head>
                                                <md-table-head class="text-center">User Type</md-table-head>
                                            </md-table-row>

                                            <md-table-row>
                                                <md-table-cell class="text-center" md-numeric>
                                                    {{ event.event.user.id }}
                                                </md-table-cell>
                                                <md-table-cell class="text-center"
                                                               v-if="event.event.user.type == 'individual' ">{{
                                                        event.event.user.details.firstname
                                                    }} {{ event.event.user.details.lastname }}
                                                </md-table-cell>
                                                <md-table-cell class="text-center"
                                                               v-if="event.event.user.type == 'organization' ">{{
                                                        event.event.user.details.name
                                                    }}
                                                </md-table-cell>
                                                <md-table-cell class="text-center">{{
                                                        event.event.user.email
                                                    }}
                                                </md-table-cell>
                                                <md-table-cell class="text-center">{{
                                                        event.event.user.username
                                                    }}
                                                </md-table-cell>
                                                <md-table-cell class="text-center">{{
                                                        event.event.user.details.phone
                                                    }}
                                                </md-table-cell>
                                                <md-table-cell class="text-center">{{
                                                        event.event.user.type
                                                    }}
                                                </md-table-cell>
                                            </md-table-row>

                                        </md-table>

                                        <md-table v-if="!showCreatedByDetails">
                                            <md-table-row>
                                                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                                <md-table-head class="text-center">Name</md-table-head>
                                                <md-table-head class="text-center">Description</md-table-head>
                                            </md-table-row>

                                            <md-table-row>
                                                <md-table-cell class="text-center" md-numeric>
                                                    {{ event.event.category.id }}
                                                </md-table-cell>
                                                <md-table-cell class="text-center">{{
                                                        event.event.category.name
                                                    }}
                                                </md-table-cell>
                                                <md-table-cell class="text-center">{{
                                                        event.event.category.description
                                                    }}
                                                </md-table-cell>
                                            </md-table-row>

                                        </md-table>
                                    </div>
                                </div>
                            </div>
                        </md-card-content>

                    </md-ripple>
                </md-card>
            </div>

            <div class="col-md-12">
                <div class="mt-5">
                    <md-card md-with-hover class="round-card">
                        <md-ripple>
                            <md-card-header>
                                <div class="md-title">Event Attendees</div>
                            </md-card-header>

                            <md-card-content>
                                <div>
                                    <md-table>
                                        <md-table-row>
                                            <md-table-head class="text-center" md-numeric>ID</md-table-head>
                                            <md-table-head class="text-center">Name</md-table-head>
                                            <md-table-head class="text-center">Email</md-table-head>
                                            <md-table-head class="text-center">Phone Number</md-table-head>
                                            <md-table-head class="text-center">Actions</md-table-head>
                                        </md-table-row>

                                        <md-table-row v-for="attendee in event.attendees" :key="attendee.id">
                                            <md-table-cell class="text-center" md-numeric>{{
                                                    attendee.id
                                                }}
                                            </md-table-cell>
                                            <md-table-cell class="text-center"
                                                           v-if="attendee.user.type == 'individual' ">
                                                {{ attendee.user.details.firstname }} {{
                                                    attendee.user.details.lastname
                                                }}
                                            </md-table-cell>
                                            <md-table-cell class="text-center"
                                                           v-if="attendee.user.type == 'organization' ">
                                                {{ attendee.user.details.name }}
                                            </md-table-cell>
                                            <md-table-cell class="text-center">{{ attendee.user.email }}</md-table-cell>
                                            <md-table-cell class="text-center">{{
                                                    attendee.user.details.phone
                                                }}
                                            </md-table-cell>
                                            <md-table-cell class="text-center">
                                                <div
                                                    class="btn-group"
                                                    role="group"
                                                    aria-label="Basic example"
                                                >

                                                    <md-button
                                                        class="md-fab md-mini bg-edit"
                                                        @click="showAttendeeDetails(attendee.payment , attendee.ticketCategory)">
                                                        <md-icon>change_circle</md-icon>
                                                        <md-tooltip md-direction="bottom">
                                                            view Attendee Details
                                                        </md-tooltip>
                                                    </md-button>

                                                </div>
                                            </md-table-cell>
                                        </md-table-row>
                                    </md-table>
                                </div>
                            </md-card-content>
                        </md-ripple>
                    </md-card>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

export default {
    name: 'EventDetails',
    data() {
        return {
            event: {
                event: "",
                purchased_tickets: "",
                attendees: "",
            },
            showCreatedByDetails: true,
            attendee_payment: [],
            attendee_ticketcategory: [],
        }
    },

    methods: {
        getEvent(id) {
            this.$spinner.show();
            axios.get('/api/events/getFullDetails/' + id)
                .then(response => {
                    this.event = response.data.data;
                    this.$notify({
                        type: 'success',
                        text: response.data.message
                    })

                })
                .catch(e => {
                    this.$notify({
                        type: 'error',
                        text: e.response.data.message
                    })
                })
                .finally(e => {
                    this.$spinner.hide();
                })
        },

        getImage(image) {
            return "/events/" + image;
        },

        getVenueImage(image) {
            return "/venue_image/" + image;
        },

        toogleShowButton(event) {
            this.showCreatedByDetails = event != true;
        },

        showAttendeeDetails(payment, ticketCategory) {
            this.$modal.show("attendeeDetails");
            this.attendee_payment = payment;
            this.attendee_ticketcategory = ticketCategory;
        },

        clearModalData(event) {
            this.attendee_payment = [];
            this.attendee_ticketcategory = [];
        },
    },

    mounted() {
        this.getEvent(this.$route.params.id);
    }
}
</script>
