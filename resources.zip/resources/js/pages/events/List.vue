<template>
  <div>
    <modal name="share-modal" :adaptive="true" :height="400">
      <div class="card h-100">
        <div class="card-body">
          <p class="card-title">Event Details:</p>

          <p>
            Name: <b>{{ event.name }}</b>
          </p>

          <p>
            Date: <b>{{ event.event_date }}</b>
          </p>

          <p>
            Description: <br />
            {{ event.description }}
          </p>
        </div>
        <div class="card-footer text-right">
          <button
            class="btn btn-primary px-3"
            v-if="$auth.type != 'individual'"
            @click="share"
          >
            Share with Member
          </button>
          <!-- <button class="btn btn-primary px-3 d-none">Share with Special Group</button> -->
        </div>
      </div>
    </modal>

    <md-card md-with-hover class="round-card">
      <md-ripple>
        <md-card-header>
          <div class="md-title">{{ filter }} Events</div>

          <div class="float-right mr-5">
            <md-menu md-direction="bottom-start" md-size="auto">
              <md-button md-menu-trigger class="md-fab md-mini bg-share">
                <md-icon>filter_alt</md-icon>
              </md-button>

              <md-menu-content>
                <md-menu-item>
                  <md-button class="" @click="loadMyEvents">
                    My Events
                  </md-button>
                </md-menu-item>

                <md-menu-item>
                  <md-button class="" @click="getUpcomingEvents">
                    Upcoming Events
                  </md-button>
                </md-menu-item>

                <md-menu-item>
                  <md-button class="" @click="getPastEvents">
                    Past Events
                  </md-button>
                </md-menu-item>
              </md-menu-content>
            </md-menu>
          </div>
        </md-card-header>

        <md-card-content>
          <div class="mt-4">
            <md-table>
              <md-table-row>
                <md-table-head class="text-center" md-numeric>ID</md-table-head>
                <md-table-head class="text-center">Name</md-table-head>
                <md-table-head class="text-center">Type</md-table-head>
                <md-table-head class="text-center">Tickets</md-table-head>
                <md-table-head class="text-center">Start Date</md-table-head>
                <md-table-head class="text-center">End Date</md-table-head>
                <md-table-head class="text-center">Image</md-table-head>
                <md-table-head class="text-center">Status</md-table-head>
                <md-table-head class="text-center">Actions</md-table-head>
              </md-table-row>

              <md-table-row v-if="events.total == 0">
                <md-table-cell colspan="12">
                  <p class="text-center">No Events Found!</p>
                </md-table-cell>
              </md-table-row>

              <md-table-row v-for="(row, index) in events" :key="row.id">
                <md-table-cell class="text-center" md-numeric>{{
                  row.unique_id
                }}</md-table-cell>
                <md-table-cell class="text-center">
                  {{ row.name }}
                </md-table-cell>
                <md-table-cell class="text-center">
                  {{ row.type }}
                </md-table-cell>
                <md-table-cell class="text-center">
                  {{ row.tickets }}
                </md-table-cell>
                <md-table-cell class="text-center">
                  {{ row.start_date | moment("dddd, Do MMMM YYYY") }}
                </md-table-cell>
                <md-table-cell class="text-center">
                  {{ row.end_date | moment("dddd, Do MMMM YYYY") }}
                </md-table-cell>
                <md-table-cell class="text-center">
                  <md-avatar class="md-large">
                    <img :src="getImage(row.image)" alt="" style="" />
                  </md-avatar>
                </md-table-cell>
                <md-table-cell class="text-center">
                  {{ row.status }}
                </md-table-cell>
                <md-table-cell class="text-center">
                  <div
                    class="btn-group"
                    role="group"
                    aria-label="Basic example"
                  >
                    <md-button
                      class="md-fab md-mini bg-edit"
                      :to="$route.path + '/' + row.id + '/edit'"
                    >
                      <md-icon>edit</md-icon>
                      <md-tooltip md-direction="bottom">Edit Event</md-tooltip>
                    </md-button>

                    <md-button
                      class="md-fab md-mini bg-share"
                      @click="confirmShare(row)"
                    >
                      <md-icon>share</md-icon>
                      <md-tooltip md-direction="bottom">Share Event</md-tooltip>
                    </md-button>

                    <md-button
                      class="md-fab md-mini bg-view"
                      :to="$route.path + '/' + row.id"
                    >
                      <md-icon>article</md-icon>
                      <md-tooltip md-direction="bottom">View Event</md-tooltip>
                    </md-button>

                    <md-button
                      class="md-fab md-mini"
                      @click="confirmDelete(row.id)"
                    >
                      <md-icon>delete</md-icon>
                      <md-tooltip md-direction="bottom"
                        >Delete Event</md-tooltip
                      >
                    </md-button>
                  </div>
                </md-table-cell>
              </md-table-row>
            </md-table>
          </div>
        </md-card-content>

        <md-card-actions>
          <pagination
            :data="pagination"
            @pagination-change-page="loadEvents"
            page="1"
          ></pagination>
        </md-card-actions>
      </md-ripple>
    </md-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      event: {},
      pagination: {},
      loading: true,
      events: {},
      api_path: "/api/events/mine",
      filter: "All",
    };
  },

  methods: {
    getImage(image) {
      return "/events/" + image;
    },

    loadEvents(page = 1) {
      this.$spinner.show();
      axios
        .get(this.api_path + "?page=" + page)
        .then((response) => {
          this.prepPagination(response.data);
          this.events = response.data.data;
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.response.data,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },

    prepPagination(data) {
      this.pagination = {
        data: data.data,
        current_page: data.meta.current_page,
        first_item: data.meta.first_item,
        last_item: data.meta.last_item,
        last_page: data.meta.last_page,
        next_page_url: data.meta.next_page_url,
        per_page: data.meta.per_page,
        previous_page_url: data.meta.previous_page_url,
        total: data.meta.total,
      };
    },

    loadMyEvents() {
      this.api_path = "/api/events/mine";
      this.loadEvents();
      this.filter = "All";
    },

    getUpcomingEvents() {
      this.api_path = "/api/events/upcoming";
      this.loadEvents();
      this.filter = "Upcoming";
    },

    getPastEvents() {
      this.api_path = "/api/events/past";
      this.loadEvents();
      this.filter = "Past";
    },

    confirmDelete(id) {
      this.$confirm({
        message: "Are you sure you want to delete this Event?",
        button: {
          no: "No",
          yes: "Yes",
        },
        callback: (confirm) => {
          if (confirm) {
            this.doDelete(id);
          }
        },
      });
    },

    doDelete(id) {
      this.$spinner.show();
      axios
        .delete("/api/events/" + id)
        .then((response) => {
          this.events = this.events.filter((event) => event.id != id);
          this.$notify({
            type: "success",
            text: response.data.message,
          });
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.response.data.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },

    confirmClose(id) {
      Swal.fire({
        html: "Are you sure you want to Close this Event?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes",
      }).then((result) => {
        if (result.isConfirmed) {
          axios
            .get("/api/events/close/" + id)
            .then((response) => {
              for (var i = 0; i < this.events.length; i++) {
                const event = this.events[i];
                if (event.id == id) {
                  event.status = "closed";
                  this.events[i] = event;
                }
              }

              swal(response.data.message);
            })
            .catch((e) => {
              swal(e.message, "error");
            });
        }
      });
    },

    confirmShare(event) {
      this.event = event;
      this.$confirm({
        message: "Are you sure you want to share this Event?",
        button: {
          no: "No",
          yes: "Yes",
        },
        callback: (confirm) => {
          if (confirm) {
            this.$modal.show("share-modal");
          }
        },
      });
    },

    share() {
      this.$modal.hide("share-modal");
      this.$spinner.show();
      axios
        .get("/api/events/" + this.event.id + "/share")
        .then((response) => {
          this.$notify({
            type: "success",
            text: response.data.message,
          });
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },
  },

  mounted() {
    this.loadEvents(1);
  },
};
</script>
