<template>
    <div>


        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">
                        <p class="card-title pt-3 px-3 h5 mb-0" v-if="!editMode">
                            Create an Event
                        </p>
                        <p class="card-title pt-3 px-3 h5 mb-0" v-if="editMode">
                            Update Event
                        </p>
                    </div>
                    <!-- <div class="md-subhead">It also have a ripple</div> -->
                </md-card-header>

                <md-card-content>
                    <div class="container mt-3" style="margin-bottom:70px !important">
                        <p>
                            <span class="mr-2">Is Free:</span>
                            <toggle-button
                                :value="false"
                                :labels="{ checked: 'Yes', unchecked: 'No' }"
                                @change="toggleMode"
                            />
                        </p>

                        <form class="mb-5"
                              @submit.prevent="editMode ? update() : create()"
                              @keydown="form.onKeydown($event)"
                        >
                            <div class="form-group">
                                <md-field :class="getValidationClass('name')">
                                    <md-icon>article</md-icon>
                                    <label>Title / Event Name</label>
                                    <md-input v-model="form.name"></md-input>
                                    <div
                                        v-if="form.errors.has('name')"
                                        class="md-error"
                                        v-html="form.errors.get('name')"
                                    />
                                    <span class="md-helper-text">Event Name</span>
                                </md-field>

                            </div>

                            <div class="form-group">
                                <md-field :class="getValidationClass('tickets')">
                                    <md-icon>dialpad</md-icon>
                                    <label>Ticket Numbers</label>
                                    <md-input
                                        type="number"
                                        v-model="form.tickets"
                                    ></md-input>
                                    <div
                                        v-if="form.errors.has('tickets')"
                                        class="md-error"
                                        v-html="form.errors.get('tickets')"
                                    />
                                    <span class="md-helper-text">Number of Tickets</span>
                                </md-field>

                            </div>

                            <div class="form-group" v-if="!form.isFree">
                                <md-field :class="getValidationClass('pricing')">
                                    <md-icon>list</md-icon>
                                    <md-select
                                        v-model="form.pricing"
                                        name="Ticket Price Category"
                                        id="category"
                                        placeholder="Ticket Price Category"
                                    >
                                        <md-option value="single">Single Price</md-option>
                                        <md-option value="multiple">Multiple Prices</md-option>
                                    </md-select>
                                    <div
                                        v-if="form.errors.has('pricing')"
                                        class="md-error"
                                        v-html="form.errors.get('pricing')"
                                    />
                                </md-field>

                            </div>

                            <div class="form-group" v-if="form.pricing == 'single'">
                                <md-field :class="getValidationClass('price')">
                                    <md-icon>attach_money</md-icon>
                                    <label>Ticket Price</label>
                                    <md-input
                                        type="number"
                                        v-model="form.price"
                                    ></md-input>
                                    <div
                                        v-if="form.errors.has('price')"
                                        class="md-error"
                                        v-html="form.errors.get('price')"
                                    />
                                    <span class="md-helper-text">Ticket Price</span>
                                </md-field>

                            </div>

                            <div
                                class="form-group bg-light"
                                v-if="form.pricing == 'multiple'"
                            >
                                <price-category
                                    v-for="(section, index) in form.ticketCategories"
                                    v-bind:key="'S' + index"
                                    :index="index"
                                    v-on:updateCategory="updateCategory"
                                    v-on:updatePrice="updatePrice"
                                    @closeSection="closeSection"
                                ></price-category>

                                <md-button
                                    class="md-dense md-raised"
                                    type="button"
                                    @click="addSection"
                                >
                                    + Add Section
                                </md-button>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <md-field :class="getValidationClass('venue')">
                                            <md-icon>location_on</md-icon>
                                            <label>Venue</label>
                                            <md-input
                                                type="text"
                                                v-model="form.venue"
                                            ></md-input>
                                            <div
                                                v-if="form.errors.has('venue')"
                                                class="md-error"
                                                v-html="form.errors.get('venue')"
                                            />
                                            <span class="md-helper-text">Event Venue</span>
                                        </md-field>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <md-field :class="getValidationClass('image')">
                                            <label>Image</label>
                                            <md-file @change="handleimage" accept="image/*"/>
                                            <div
                                                v-if="form.errors.has('image')"
                                                class="md-error"
                                                v-html="form.errors.get('image')"
                                            />
                                            <span class="md-helper-text" v-if="!editMode">Event Image</span>
                                            <span class="md-helper-text" v-if="editMode"
                                            >Leave blank if you want to retain the old image</span
                                            >
                                        </md-field>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <md-field :class="getValidationClass('start_date')">
                                            <md-icon>event</md-icon>
                                            <label>Start Date</label>
                                            <md-input
                                                type="date"
                                                v-model="form.start_date"
                                            ></md-input>
                                            <div
                                                v-if="form.errors.has('start_date')"
                                                class="md-error"
                                                v-html="form.errors.get('start_date')"
                                            />
                                            <span class="md-helper-text">Start Date</span>
                                        </md-field>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <md-field :class="getValidationClass('end_date')">
                                            <md-icon>event</md-icon>
                                            <label>End Date</label>
                                            <md-input
                                                type="date"
                                                v-model="form.end_date"
                                            ></md-input>
                                            <div
                                                v-if="form.errors.has('end_date')"
                                                class="md-error"
                                                v-html="form.errors.get('end_date')"
                                            />
                                            <span class="md-helper-text">End Date</span>
                                        </md-field>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <md-field :class="getValidationClass('category_id')">
                                        <md-icon>list</md-icon>
                                        <label for="movies">Event Category</label>
                                        <md-select
                                            v-model="form.category_id"
                                            name="category_id"
                                            id="category_id"
                                        >
                                            <md-option
                                                v-for="category in categories"
                                                :value="category.id"
                                                :key="category.id"
                                            >{{ category.name }}
                                            </md-option
                                            >
                                        </md-select>
                                        <div
                                            v-if="form.errors.has('category_id')"
                                            class="md-error"
                                            v-html="form.errors.get('category_id')"
                                        />
                                    </md-field>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <md-field :class="getValidationClass('venue_image')">
                                            <label>Venue Image</label>
                                            <md-file @change="handlevenueimage" accept="image/*"/>
                                            <div
                                                v-if="form.errors.has('venue_image')"
                                                class="md-error"
                                                v-html="form.errors.get('venue_image')"
                                            />
                                            <span class="md-helper-text" v-if="!editMode">Event Venue Image</span>
                                            <span class="md-helper-text" v-if="editMode"
                                            >Leave blank if you want to retain the old image</span
                                            >
                                        </md-field>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-6 mt-3">
                                    <md-field :class="getValidationClass('start_time')">
                                        <md-icon>schedule</md-icon>
                                        <label>Start Time</label>
                                        <md-input
                                            type="time"
                                            v-model="form.start_time"
                                        ></md-input>
                                        <div
                                            v-if="form.errors.has('start_time')"
                                            class="md-error"
                                            v-html="form.errors.get('start_time')"
                                        />
                                        <span class="md-helper-text">Start Time</span>
                                    </md-field>
                                </div>

                                <div class="col-md-6 mt-3">
                                    <md-field :class="getValidationClass('end_time')">
                                        <md-icon>schedule</md-icon>
                                        <label>End Time</label>
                                        <md-input
                                            type="time"
                                            v-model="form.end_time"
                                        ></md-input>
                                        <div
                                            v-if="form.errors.has('end_time')"
                                            class="md-error"
                                            v-html="form.errors.get('end_time')"
                                        />
                                        <span class="md-helper-text">End Time</span>
                                    </md-field>
                                </div>
                            </div>

                            <div class="form-group">
                                <md-field :class="getValidationClass('type')">
                                    <md-icon>list</md-icon>
                                    <md-select
                                        v-model="form.type"
                                        name="Type"
                                        id="type"
                                        placeholder="Type"
                                    >
                                        <md-option value="open">Open</md-option>
                                        <md-option value="close">Closed</md-option>
                                        <md-option value="semi-open">Semi Open</md-option>
                                    </md-select>
                                    <div
                                        v-if="form.errors.has('type')"
                                        class="md-error"
                                        v-html="form.errors.get('type')"
                                    />
                                </md-field>
                            </div>

                            <div class="form-group">
                                <md-field :class="getValidationClass('description')">
                                    <label>Description</label>
                                    <md-textarea v-model="form.description"></md-textarea>
                                    <div
                                        v-if="form.errors.has('description')"
                                        class="md-error"
                                        v-html="form.errors.get('description')"
                                    />
                                    <md-icon>description</md-icon>
                                </md-field>
                            </div>

                            <button
                                class="btn btn-primary px-5 float-right"
                                :disabled="form.busy"
                            >
                                <span v-if="editMode">Update Event</span>
                                <span v-if="!editMode">Create Event</span>
                            </button>
                        </form>
                    </div>
                </md-card-content>
            </md-ripple>
        </md-card>
    </div>
</template>

<script>
import PriceCategory from "../../components/TicketPriceCategory.vue";
import VueTimepicker from "vue2-timepicker/src/vue-timepicker.vue";

export default {
    data() {
        return {
            editMode: false,
            categories: [],
            form: new Form({
                id: "",
                name: "",
                type: "",
                venue: "",
                start_date: "",
                end_date: "",
                start_time: "",
                end_time: "",
                price: 0,
                tickets: "",
                description: "",
                isFree: false,
                pricing: "",
                image: "",
                category_id: "",
                venue_image: "",
                ticketCategories: [
                    {
                        name: "",
                        price: 0,
                    },
                ],
            }),
        };
    },

    components: {
        PriceCategory,
        VueTimepicker,
    },

    methods: {

        getValidationClass(fieldName) {
            const field = this.form.errors.has(fieldName);
            if (field) {
                return "md-invalid";
            }
        },

        create() {
            this.$spinner.show();
            this.form
                .post("/api/events")
                .then((response) => {
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                    this.form.reset();
                })
                .catch((e) => {
                    // console.log("Error", e);
                    if (e.response.status == 422) {
                        this.form.errors.set(e.response.data.error);
                        console.log("422", e.response);
                    }

                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                })
                .finally(() => {
                    this.$spinner.hide();
                });
        },

        update() {
            this.form
                .put("/api/events/" + this.form.id)
                .then((response) => {
                    this.$notify({
                        type: "success",
                        text: response.data.message,
                    });
                })
                .catch((e) => {
                    if (e.response.status == 422) {
                        this.form.errors.set(e.response.data.error);
                        console.log("422", e.response);
                    }
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                });
        },

        loadEvent(id) {
            axios
                .get("/api/events/" + id)
                .then((response) => {
                    this.form.fill(response.data.data);
                    response.data.data.isFree == "false" ? this.form.isFree = false : this.form.isFree = true;
                })
                .catch((e) => {
                    this.$notify({
                        type: "error",
                        text: e.response.data.message,
                    });
                    // console.log(e);
                });
        },

        toggleMode(e) {
            this.form.isFree = e.value;
        },

        updateTicketCategory(event) {
            console.log("Data", event.target.value);
        },

        addSection() {
            this.form.ticketCategories.push({
                name: "",
                price: 0,
            });
        },

        updateCategory(name, index) {
            this.form.ticketCategories[index].name = name;
        },

        updatePrice(price, index) {
            this.form.ticketCategories[index].price = price;
        },

        closeSection(index) {
            this.form.ticketCategories.splice(index, 1);
        },

        handleimage(event) {
            let file = event.target.files[0];
            //console.log(form)
            let reader = new FileReader();
            reader.onload = (event) => {
                this.form.image = event.target.result;
                console.log(event.target.result);
            };
            reader.readAsDataURL(file);

            // this.form.image = event.target.files[0];
            // console.log(event.target.files[0])
        },

        handlevenueimage(event) {
            let file = event.target.files[0];
            //console.log(form)
            let reader = new FileReader();
            reader.onload = (event) => {
                this.form.venue_image = event.target.result;
                console.log(event.target.result);
            };
            reader.readAsDataURL(file);

            // this.form.venue_image = event.target.files[0];
            // console.log(event.target.files[0])
        },

        getCategories() {
            axios.get("/api/events/category/list").then((response) => {
                this.categories = response.data.data;
                // console.log(response.data.data);
            });
        },
    },

    mounted() {
        if (this.$route.params.id) {
            this.editMode = true;
            this.loadEvent(this.$route.params.id);
            // alert(this.$route.params.id)
        }

        this.getCategories();
    },
};
</script>
