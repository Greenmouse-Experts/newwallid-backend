<template>
  <div>
    <modal name="categories-modal" :adaptive="true">
      <div class="card h-100">
        <form @submit.prevent="initPayment" @keydown="form.onKeydown($event)">
          <div class="card-body">
            <div class="form-group">
              <label>Ticket Category</label>
              <select class="form-control" required v-model="category_id">
                <option
                  v-for="tc in event.ticketCategories"
                  :key="tc.id"
                  :value="tc.id"
                >
                  {{ tc.name }}
                </option>
              </select>
            </div>
          </div>

          <div class="card-footer text-right">
            <button class="btn btn-danger">Continue</button>
          </div>
        </form>
      </div>
    </modal>

    <md-card md-with-hover class="round-card mb-4">
      <md-ripple>
        <md-card-header>
          <div class="md-title text-dark"><b> Details</b></div>
          <!-- <div class="md-subhead">It also have a ripple</div> -->
        </md-card-header>

        <md-card-content v-if="event">
          <!-- <p class="card-title">Details</p> -->
          <div class="row">
            <div class="col-md-3">
              <p class="mb-4 text-capitalize">
                <span class="small text-muted">Title</span> <br />
                {{ event.name }}
              </p>

              <p class="mb-4">
                <span class="small text-muted">Date</span> <br />
                {{ event.start_date | moment("dddd, Do MMMM YYYY") }}
              </p>

              <p class="mb-4">
                <span class="small text-muted">Tickets</span> <br />
                {{ event.tickets }}
              </p>

              <p class="mb-4">
                <span class="small text-muted">Available Tickets</span> <br />
                {{ event.tickets - purchased_tickets }}
              </p>

              <p class="mb-4">
                <span class="small text-muted">Event ID</span> <br />
                {{ event.unique_id }}
              </p>
            </div>

            <div
              class="col-md-4"
              style="border-left: solid 2px; border-right: solid 2px"
            >
              <div class="">
                <div class="item_image">
                  <img
                    class="text-center"
                    style="border-radius: 12px; width: 100px; height: 100px"
                    :src="getImage(event.image)"
                    alt=""
                  />
                  <p class="text-center mt-1">Event Image</p>
                </div>

                <div class="item_image">
                  <img
                    style="border-radius: 12px; width: 100px; height: 100px"
                    :src="getVenueImage(event.venue_image)"
                    alt=""
                  />
                  <p class="text-center mt-1">Event Venue Image</p>
                </div>
              </div>
            </div>

            <div class="col-md-5">
              <div>
                <h4>My Ticket:</h4>
              </div>
              <div class="container" v-if="!ticket">
                You dont have a ticket for this event
              </div>

              <div class="container" v-if="ticket">
                <div style="margin: 0 auto">
                  <div class="row">
                    <div class="col-md-6 float-left">
                      <p>Ticket ID : {{ ticket.id }}</p>
                      <p>Event ID : {{ ticket.event_id }}</p>
                    </div>

                    <div
                      class="float-right col-md-6"
                      v-if="ticket.pricing == 'multiple'"
                    >
                      <p>
                        Ticket Category :
                        <b class="text-uppercase">
                          {{ ticket.ticket_category_name }}
                        </b>
                      </p>
                      <p>
                        Ticket Price :
                        {{ ticket.tickets_category_price | formatCurrency }}
                      </p>
                    </div>

                    <div
                      class="float-right col-md-6"
                      v-if="ticket.pricing == 'single'"
                    >
                      <!-- <p>Ticket Category: SINGLE</p> -->
                      <p>Ticket Price : {{ ticket.price | formatCurrency }}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div v-if="ticket">
                <div class="col-md-12">
                  <div class="text-center">
                    <vue-qr
                      v-if="ticket.pricing == 'multiple'"
                      :logoSrc="qrimage()"
                      :text="
                        'Ticket ID: ' +
                        ticket.id +
                        ', Event ID: ' +
                        ticket.event_id +
                        ', Category: ' +
                        ticket.ticket_category_name +
                        ', Price: ' +
                        ticket.tickets_category_price
                      "
                      :size="200"
                    ></vue-qr>

                    <vue-qr
                      v-if="ticket.pricing == 'single'"
                      :logoSrc="qrimage()"
                      :text="
                        'Ticket ID: ' +
                        ticket.id +
                        ', Event ID: ' +
                        ticket.event_id +
                        ', Price: ' +
                        ticket.price
                      "
                      :size="200"
                    ></vue-qr>

                    <vue-qr
                      v-if="event.isFree == 'true'"
                      :logoSrc="qrimage()"
                      :text="
                        'Ticket ID: ' +
                        ticket.id +
                        ', Event ID: ' +
                        ticket.event_id +
                        ', Price: ' +
                        ticket.price
                      "
                      :size="200"
                    ></vue-qr>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </md-card-content>
      </md-ripple>
    </md-card>

    <md-card md-with-hover class="round-card">
      <md-ripple>
        <md-card-header>
          <div class="md-title text-dark"><b>Pricing</b></div>
          <!-- <div class="md-subhead">It also have a ripple</div> -->
        </md-card-header>

        <md-card-content v-if="event">
          <div>
            <p class="text-capitalize">
              <span class="small text-muted">Ticket Type</span> <br />
              {{ event.isFree == "false" ? event.pricing : "Free Event" }}
            </p>
          </div>

          <div v-if="event.pricing == 'multiple'">
            <p class="mb-4" v-for="tc in event.ticketCategories" :key="tc.id">
              <span class="small text-muted">{{ tc.name }}</span> <br />
              ₦{{ tc.price | formatCurrency }}
            </p>
          </div>

          <div v-if="event.pricing == 'single'">
            <p class="mb-4">₦{{ event.price | formatCurrency }}</p>
          </div>

          <div class="text-right">
            <md-button
              v-if="
                event_request.status == 'pending' &&
                event.tickets - purchased_tickets > 0
              "
              :disabled="ticket"
              class="md-dense md-raised md-accent"
              @click="event.isFree == 'false' ? process() : freeProcess()"
            >
              {{ event.isFree == "false" ? "Buy Ticket" : "Get Ticket" }}
            </md-button>

            <md-chip
              v-if="event_request.status == 'approved'"
              class="bg-success"
              md-clickable
              >You have a Ticket for this event already</md-chip
            >

            <md-chip
              v-if=" event_request.status == 'pending' && event.tickets - purchased_tickets == 0"
              class="bg-warning"
              md-clickable
              >No more Tickets Available</md-chip
            >

            <md-chip
              v-if="event_request.status == 'declined'"
              class="md-accent"
              md-clickable
              >Sorry but you can't buy ticket for a declined Event
              invitation</md-chip
            >
          </div>
        </md-card-content>
      </md-ripple>
    </md-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      event: null,
      event_request: null,
      purchased_tickets: 0,
      ticket: null,
      category_id: null,
      value: "https://example.com",
    };
  },

  methods: {
    getEvent(id) {
      this.$spinner.show();
      axios
        .get("/api/events/" + id)
        .then((response) => {
          this.event = response.data.data;
          this.event_request = response.data.rdata;
          this.purchased_tickets = response.data.pdata;
          this.$notify({
            title: "success",
            text: response.data.message,
          });
        })
        .catch((e) => {
          this.$notify({
            title: "Error",
            text: e.response.data.message,
          });
        })
        .finally((e) => {
          this.$spinner.hide();
        });
    },

    process() {
      if (this.event.pricing != "single") {
        this.$modal.show("categories-modal");
      } else {
        this.initPayment();
      }
    },

    freeProcess() {
      this.$spinner.show();

      let data = {
        event_id: this.event.id,
      };

      axios
        .post("/api/tickets/buy/free", data)
        .then((response) => {
          this.$notify({
            type: response.data.status ? "success" : "warn",
            text: response.data.message,
          });

          this.getEvent(this.$route.params.id);
          this.getEventTicket(this.$route.params.id);
        })
        .catch((error) => {
          this.$notify({
            type: "error",
            text: error.response.data.message,
          });
          // console.log(error.response.data)
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },

    initPayment() {
      if (this.event.pricing != "single" && !this.category_id) {
        this.$notify({
          type: "warn",
          text: "Please select Ticket Category",
        });
      } else {
        this.$modal.hide("categories-modal");
        this.$spinner.show();

        let data = {
          event_id: this.event.id,
          category_id: this.category_id,
        };

        // console.log("Data", data);

        axios
          .post("/api/tickets/buy", data)
          .then((response) => {
            this.$notify({
              type: response.data.status ? "success" : "warn",
              text: response.data.message,
            });

            if (response.data.status && response.data.data.link) {
              localStorage.setItem("event_id", this.event.id);
              localStorage.setItem("paymentFor", "ticket");

              window.location.href = response.data.data.link;
            }
          })
          .catch((error) => {
            this.$notify({
              type: "error",
              text: error.response.data.message,
            });
            // console.log(error.response.data)
          })
          .finally(() => {
            this.$spinner.hide();
          });
      }
    },

    getImage(image) {
      return "/events/" + image;
    },

    getVenueImage(image) {
      return "/venue_image/" + image;
    },

    qrimage() {
      return "/images/favicon.png";
    },

    getEventTicket(id) {
      this.$spinner.show();
      axios
        .get("/api/tickets/" + id)
        .then((response) => {
          this.ticket = response.data.data;
          console.log(response);
          this.$notify({
            title: "success",
            text: response.data.message,
          });
        })
        .catch((e) => {
          this.$notify({
            title: "Error",
            text: e.response.data.message,
          });
        })
        .finally((e) => {
          this.$spinner.hide();
        });
    },
  },

  mounted() {
    this.getEvent(this.$route.params.id);
    this.getEventTicket(this.$route.params.id);
  },
};
</script>
