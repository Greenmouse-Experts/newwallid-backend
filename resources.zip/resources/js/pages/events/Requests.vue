<template>
  <div>
    <md-card md-with-hover class="round-card">
      <md-ripple>
        <md-card-header>
          <div class="md-title">Request Status</div>
          <!-- <div class="md-subhead">It also have a ripple</div> -->
        </md-card-header>

        <md-card-content>
          <div class="container">
            <form
              class=""
              @submit.prevent="getRequests()"
              @keydown="form.onKeydown($event)"
            >
              <div class="row mb-4">
                <div class="col-md-10">
                  <md-field>
                    <label for="event_id">Select Event</label>
                    <md-select
                      v-model="form.event_id"
                      name="event_id"
                      id="event_id"
                    >
                      <md-option
                        v-for="event in events"
                        :value="event.unique_id"
                        :key="event.id"
                      >
                        {{ event.name }}
                      </md-option>
                    </md-select>
                  </md-field>
                </div>

                <div class="col-md-2">
                  <button class="btn btn-primary px-5">Fetch</button>
                </div>
              </div>
            </form>
          </div>
        </md-card-content>
      </md-ripple>
    </md-card>

    <md-card md-with-hover class="round-card mt-4">
      <md-ripple>
        <md-card-header>
          <div class="md-title">Event Requests</div>
          <!-- <div class="md-subhead">It also have a ripple</div> -->
        </md-card-header>

        <md-card-content>

          <div class="container">
            <md-table>
              <md-table-row>
                <md-table-head class="text-center" md-numeric>#</md-table-head>
                <md-table-head class="text-center">Event Title</md-table-head>
                <md-table-head class="text-center">Invitee Name</md-table-head>
                <md-table-head class="text-center">Invitee Email</md-table-head>
                <md-table-head class="text-center"
                  >Invitation Status</md-table-head
                >
              </md-table-row>

              <md-table-row v-for="(row, index) in invitations" :key="row.id">
                <md-table-cell class="text-center" md-numeric>
                  {{ row.id }}
                </md-table-cell>
                <md-table-cell class="text-center">
                  {{ row.event.name }}</md-table-cell
                >
                <md-table-cell
                  class="text-center"
                  v-if="row.user.type == 'individual'"
                >
                  {{
                    row.user.details.firstname + " " + row.user.details.lastname
                  }}</md-table-cell
                >
                <md-table-cell
                  class="text-center"
                  v-if="row.user.type == 'organization'"
                >
                  {{ row.user.details.name }}</md-table-cell
                >
                <md-table-cell class="text-center">
                  {{ row.user.email }}</md-table-cell
                >
                <md-table-cell class="text-center">
                  <span
                    v-if="row.status == 'pending'"
                    class="p-2 bg-info rounded text-white"
                  >
                    Pending
                  </span>

                  <span
                    v-if="row.status == 'approved'"
                    class="p-2 bg-success rounded text-white"
                  >
                    Accepted
                  </span>

                  <span
                    v-if="row.status == 'declined'"
                    class="p-2 bg-warning rounded text-white"
                  >
                    Declined
                  </span>
                </md-table-cell>
              </md-table-row>
            </md-table>
          </div>
        </md-card-content>

        <md-card-actions>
          <pagination
            :data="pagination"
            @pagination-change-page="getRequests"
            page="1"
          ></pagination>
        </md-card-actions>
      </md-ripple>
    </md-card>
  </div>
</template>

<script>
export default {
  name: "EventRequest",
  data() {
    return {
      events: [],
      pagination: {},
      invitations: [],

      form: new Form({
        event_id: "",
        username: "",
      }),
    };
  },
  computed: {
    url: () => {
      return "event-info";
    },
  },
  methods: {
    getRequests(page = 1) {
      this.$spinner.show();
      axios
        .get(`/api/events/${this.form.event_id}/requests?page=${page}`)
        .then((response) => {
          console.log("Data", response);

          this.$notify({
            type: response.data.status ? "success" : "warn",
            text: response.data.message,
          });

          this.prepPagination(response.data);
          this.invitations = response.data.data;
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },

    prepPagination(data) {
      this.pagination = {
        data: data.data,
        current_page: data.meta.current_page,
        first_item: data.meta.first_item,
        last_item: data.meta.last_item,
        last_page: data.meta.last_page,
        next_page_url: data.meta.next_page_url,
        per_page: data.meta.per_page,
        previous_page_url: data.meta.previous_page_url,
        total: data.meta.total,
      };
    },

    loadAllEvents() {
      this.$spinner.show();
      axios
        .get("/api/events/all")
        .then((response) => {
          this.events = response.data.data;
          this.$notify({
            type: response.data.status ? "success" : "warn",
            text: response.data.message,
          });
        })
        .catch((e) => {
          this.$notify({
            type: "error",
            text: e.message,
          });
        })
        .finally(() => {
          this.$spinner.hide();
        });
    },
  },
  mounted() {
    this.loadAllEvents();
  },
};
</script>
