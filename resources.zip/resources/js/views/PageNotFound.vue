<template>
	<div>
		Page not found 404
	</div>
</template>

<script>
	export default {
		name: 'PageNotFound',
		data() {
			return {

			}
		}
	}
</script>