// import "@popperjs/core";
import bootstrap from 'bootstrap';

import './popover';
import './scrollbar';
import './search';
import './sidebar';
import './email';
import './utils';
