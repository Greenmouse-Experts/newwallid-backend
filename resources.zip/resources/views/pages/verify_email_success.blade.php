@extends('layouts.app')

@section('partials.navbar') @endsection

@section('content')
    <div class="container py-5" style="margin-top: 167px">

        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">Email Verified Successfully</div>
                </md-card-header>

                <md-card-content>
                    <p class="mb-3"> Your Email has been successfully verified, Kindly go back to the  <b>WALL-ID</b> mobile app to login or click on the
                        button below to log in to the <b>WALL-ID</b> web-app
                    </p>
                    <p class="mb-5">
                        <md-button class="md-raised md-dense md-primary float-right" href="{{ route('login') }}"> Login</md-button>
                    </p>
                </md-card-content>
            </md-ripple>
        </md-card>
    </div>
@endsection

@section('partials.footer') @endsection
