@extends('layouts.app')

@section('partials.navbar') @endsection

@section('content')
    <div class="container py-5" style="margin-top: 155px; margin-bottom: 12px">


        <md-card md-with-hover class="round-card">
            <md-ripple>
                <md-card-header>
                    <div class="md-title">Account created successfully !!</div>
                </md-card-header>

                <md-card-content>
                    <p class="mb-3">
                        Your account has been created successfully. Check your email for verification.
                    </p>
                    <p class="mb-5">
                        <md-button href="/" class="md-primary md-dense md-raised float-right ">Home</md-button>
                    </p>
                </md-card-content>

            </md-ripple>
        </md-card>
    </div>
@endsection

@section('partials.footer') @endsection
