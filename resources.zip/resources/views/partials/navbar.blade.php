
<!-- Header Section -->
<header class="header-menu-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 main-menu-container">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a href="/" class="navbar-brand">
                        <img style="width: 170px" src="/new_assets/images/logo.png" alt="WALLID">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent"
                            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">

                        <ul class="navbar-nav ml-auto main-menu align-items-center">

                            <li class="nav-item">
                                <a href="/" class="nav-link page-scroll">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="/about" class="nav-link page-scroll">About Us</a>
                            </li>
                            <li class="nav-item">
                                <a href="/pricing" class="nav-link page-scroll">Pricing</a>
                            </li>
                            <li class="nav-item">
                                <a href="/faq" class="nav-link page-scroll">FAQs</a>
                            </li>
                            <li class="nav-item">
                                <a href="/contact" class="nav-link page-scroll">Contact</a>
                            </li>

                        </ul>

                        <ul class="nav_btn">
                            @guest
                                <li class="nav-item">
                                    <a href="/login" class="nav-button-link-login"
                                    ><i class="fa fa-user"></i> <span>Login</span></a>
                                </li>
                                <li class="nav-item">
                                    <md-button href="/register/account-type"
                                       class="nav-button-link-signup"><i class="fas fa-sign-in-alt"></i>
                                        <span>Sign Up</span></md-button>
                                </li>
                            @else
                                <li class="nav-item">
                                    <a href="/home"
                                       class="nav-button-link-signup"><i class="fas fa-sign-in-alt"></i>
                                        <span>Dashboard</span></a>
                                </li>
                            @endguest
                        </ul>

                    </div>
                </nav>
            </div>
        </div>
    </div>
</header>
<!-- Header Section Ends -->
