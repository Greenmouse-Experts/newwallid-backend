<nav class="sidebar sidebar-offcanvas shadow-sm" id="sidebar">
  <ul class="nav">
    <li class="nav-item">
      <router-link to="/{{Auth::user()->type}}" class="nav-link">
          <i class="icon-grid menu-icon"></i>
          <span class="menu-title">Dashboard</span>
      </router-link>
    </li>

    <li class="nav-item ">
      <a class="nav-link" data-toggle="collapse" href="#events" aria-expanded="true" class="nav-link" >
        <i class="icon-layout menu-icon"></i>
        <span class="menu-title">Events</span>
        <i class="menu-arrow"></i>
      </a>

      <div class="collapse show" id="events">
        <ul class="nav flex-column sub-menu">
            <li class="nav-item">

              <router-link to="/{{Auth::user()->type}}/events/create" class="nav-link">
                {{-- <i class="fa fa-trash"></i> --}}
                <span>Create Event</span>
              </router-link>
            </li>

            <li class="nav-item">
              <router-link to="/{{Auth::user()->type}}/events" class="nav-link">
                <span>View Events</span>
              </router-link>
            </li>

            <li class="nav-item">
              <router-link to="/{{Auth::user()->type}}/events/invites" class="nav-link">
                <span>Event Invites</span>
              </router-link>
            </li>

            <li class="nav-item">
              <router-link to="/{{Auth::user()->type}}/events/requests" class="nav-link">
                <span>Event Requests</span>
              </router-link>
            </li>
        </ul>
      </div>
    </li>

 {{--Individual users Tab Menu --}}
    @if(Auth::user()->type == 'individual')
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#organizations" aria-expanded="true" aria-controls="ui-basic">
          <i class="icon-layout menu-icon"></i>
          <span class="menu-title">Organizations</span>
          <i class="menu-arrow"></i>
        </a>

        <div class="collapse show" id="organizations">
          <ul class="nav flex-column sub-menu">

              <li class="nav-item">
                <router-link to="/{{Auth::user()->type}}/organizations/join-request" class="nav-link">
                  <span>Join Requests</span>
                </router-link>
              </li>

              <li class="nav-item">
                <router-link to="/{{Auth::user()->type}}/organizations" class="nav-link">
                  <span>Joined Organization</span>
                </router-link>
              </li>

          </ul>

        </div>
      </li>
    @endif
 {{--End Individual users Tab Menu --}}



    {{--Organization users Tab Menu --}}
    @if(Auth::user()->type == 'organization')
      <li class="nav-item">
      <a class="nav-link" data-toggle="collapse" href="#organizations" aria-controls="form-elements" aria-expanded="true" class="nav-link">
        <i class="icon-columns menu-icon"></i>
        <span class="menu-title">Membership</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse show" id="organizations">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item">
            <router-link to="/organization/members/requests" class="nav-link">
              <span>Requests</span>
            </router-link>
          </li>

          <li class="nav-item">
            <router-link to="/organization/members" class="nav-link">
              <span>Members</span>
            </router-link>
          </li>

          <li class="nav-item">
            <router-link to="/organization/subscriptions/plans" class="nav-link">
              <span>Subscription Plans</span>
            </router-link>
          </li>

          <li class="nav-item">
            <router-link to="/organization/subscriptions" class="nav-link">
              <span>Subscriptions</span>
            </router-link>
          </li>
        </ul>
      </div>
    </li>

    @endif
 {{--End Organization users Tab Menu --}}



{{-- ID Management for all users --}}
    <li class="nav-item ">
        <a class="nav-link" data-toggle="collapse" href="#id_management" aria-expanded="true" class="nav-link" >
          <i class="icon-layout menu-icon"></i>
          <span class="menu-title">ID Management</span>
          <i class="menu-arrow"></i>
        </a>

        <div class="collapse show" id="id_management">
          <ul class="nav flex-column sub-menu">
              <li class="nav-item">

                <router-link to="/{{Auth::user()->type}}/id_card" class="nav-link">
                  {{-- <i class="fa fa-trash"></i> --}}
                  <span>ID Card Management</span>
                </router-link>
              </li>

              <li class="nav-item">

                <router-link to="/{{Auth::user()->type}}/id_card/view" class="nav-link">
                  {{-- <i class="fa fa-trash"></i> --}}
                  <span>My ID Cards</span>
                </router-link>
              </li>

          </ul>
        </div>
      </li>

  </ul>
</nav>
